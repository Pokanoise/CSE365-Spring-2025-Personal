package databasePart1;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;

import application.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;



/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 */
public class DatabaseHelper {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/test";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	private Connection connection = null;
	private Statement statement = null; 
	//	PreparedStatement pstmt

	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			// You can use this command to clear the database and restart from fresh.
			//statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	private void createTables() throws SQLException {
	    // Create the cse360users table without the ID column
	    String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
	            + "userName VARCHAR(255) PRIMARY KEY, "  // userName is now the primary key
	            + "password VARCHAR(255), "
	            + "role VARCHAR(20))";
	    statement.execute(userTable);

	    // Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	            + "isUsed BOOLEAN DEFAULT FALSE)";
	    statement.execute(invitationCodesTable);

	    // Create the questions table
	    String questionsTable = "CREATE TABLE IF NOT EXISTS questions ("
	            + "question_text TEXT NOT NULL, "
	            + "answer_text TEXT NULL)";
	    statement.execute(questionsTable);
	}



	// Check if the database is empty
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	// Registers a new user in the database.
	public boolean register(User user) throws SQLException {
		String insertUser = "INSERT INTO cse360users (userName, password, role) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.executeUpdate();
		}
		
		return true; // could not register
	}

	// Validates a user's login credentials.
	public boolean login(User user) throws SQLException {
		String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ? AND role = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}
	
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}
	
	// Retrieves the role of a user from the database using their UserName.
	public String getUserRole(String userName) {
	    String query = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("role"); // Return the role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode() {
	    String code = UUID.randomUUID().toString().substring(0, 4); // Generate a random 4-character code
	    String query = "INSERT INTO InvitationCodes (code) VALUES (?)";

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
	}
	
	// Validates an invitation code to check if it is unused.
	public boolean validateInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            // Mark the code as used
	            markInvitationCodeAsUsed(code);
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	// Marks the invitation code as used in the database.
	private void markInvitationCodeAsUsed(String code) {
	    String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	// Closes the database connection and statement.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}
	// Resets all users in the database (if you want a complete reset)
	public void resetDatabase() throws SQLException {
	    String sql = "DELETE FROM cse360users";  // Correct table name
	    try (Statement stmt = connection.createStatement()) {
	        stmt.executeUpdate(sql);
	    }
	}
	// Deletes all users from the database
	public void resetAllUsers() throws SQLException {
	    String sql = "DELETE FROM cse360users";
	    try (Statement stmt = connection.createStatement()) {
	        stmt.executeUpdate(sql);
	        System.out.println("All users have been deleted from the database.");
	    }
	}

	// Resets only the admin account
	public void resetAdmin() throws SQLException {
	    String sql = "DELETE FROM cse360users WHERE role = 'admin'";
	    try (Statement stmt = connection.createStatement()) {
	        stmt.executeUpdate(sql);
	    }
	}
	
	public boolean saveQuestion(String question, String answers) throws SQLException {
	    String query = "INSERT INTO questions (question_text, answer_text) VALUES (?, ?)";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, question);
	        stmt.setString(2, answers);
	        stmt.executeUpdate();
	    }
	    
	    return true;
	}

	
	
	public List<String> getQuestions() throws SQLException {
	    List<String> questions = new ArrayList<>();
	    String query = "SELECT question_text FROM questions";
	    
	    try (Statement stmt = connection.createStatement();
	         ResultSet rs = stmt.executeQuery(query)) {
	        while (rs.next()) {
	            questions.add(rs.getString("question_text"));
	        }
	    }
	    return questions;
	}
	public List<String> getAnswers() throws SQLException {
		List<String> answers = new ArrayList<>();
		String query = "SELECT answer_text FROM questions";
		
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {
					while (rs.next()) {
						answers.add(rs.getString("answer_text"));
					}
				}
				return answers;
	}
	
    public List<String> getQuestionsWithAnswers() throws SQLException {
        List<String> questionsWithAnswers = new ArrayList<>();
        String query = "SELECT question_text, answer_text FROM questions";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String question = rs.getString("question_text");
                String answer = rs.getString("answer_text");
                questionsWithAnswers.add("Q: " + question + "\nA: " + answer);
            }
        }
        return questionsWithAnswers;
    }
    
    public List<String> getUnansweredQuestions() throws SQLException {
        List<String> questions = new ArrayList<>();
        String query = "SELECT question_text FROM questions WHERE answer_text = ''";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                questions.add("Q: " + rs.getString("question_text"));
            }
        }
        return questions;
    }
    
    public void updateAnswer(String question, String answer) throws SQLException {
        String sql = "UPDATE questions SET ANSWER_TEXT = ? WHERE QUESTION_TEXT = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, answer);
            stmt.setString(2, question);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("SQL Executed: " + stmt.toString()); // Debugging log
            System.out.println("Rows updated: " + rowsAffected); // Debugging log
        }
    }

    
    public List<String> getAllQuestionsWithAnswers() throws SQLException {
        List<String> questionsWithAnswers = new ArrayList<>();
        String query = "SELECT question_text, answer_text FROM questions";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String question = rs.getString("question_text");
                String answer = rs.getString("answer_text");  // Can be NULL

                // ✅ Fix: Handle NULL values correctly
                if (answer == null || answer.trim().isEmpty()) {
                    questionsWithAnswers.add("Q: " + question + "\nA: (No answer yet)");
                } else {
                    questionsWithAnswers.add("Q: " + question + "\nA: " + answer);
                }
            }
        }
        return questionsWithAnswers;
    }
    
    public void deleteQuestion(String question) throws SQLException {
    	String sql = "DELETE FROM questions WHERE QUESTION_TEXT = ?";
    	
    	try (PreparedStatement stmt = connection.prepareStatement(sql)) {
    		stmt.setString(1, question.trim());
    		int rowsAffected = stmt.executeUpdate();
    		System.out.println("Deleted Question: " + question + ", Rows affected: " + rowsAffected);
    	}
    }
    
    public void clearAnswer(String question) throws SQLException {
    	String sql = "UPDATE questions SET ANSWER_TEXT = NULL WHERE QUESTION_TEXT = ?";
    	
    	try(PreparedStatement stmt = connection.prepareStatement(sql)) {
    		stmt.setString(1, question.trim());
    		int rowsAffected = stmt.executeUpdate();
    		System.out.println("Cleared Answer for Question: " + question + ", Rows affected: " + rowsAffected);
    	}
    }
    
    public boolean updateAnswerWithRole(String question, String newAnswer, String role) throws SQLException {
        // Check for valid roles: only admin or reviewer can update
        if (!role.equals("admin") && !role.equals("reviewer")) {
            System.out.println("Access Denied: Only admins and reviewers can update questions.");
            return false;
        }

        String sql = "UPDATE questions SET answer_text = ? WHERE question_text = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, newAnswer);
            stmt.setString(2, question);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Role-based update (Role: " + role + "): Rows updated: " + rowsAffected);
            return rowsAffected > 0;
        }
    }

    public boolean deleteQuestionWithRole(String question, String role) throws SQLException {
        // Check for valid roles: only admin can delete
        if (!role.equals("admin")) {
            System.out.println("Access Denied: Only admins can delete questions.");
            return false;
        }

        String sql = "DELETE FROM questions WHERE question_text = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, question);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Role-based delete (Role: " + role + "): Rows deleted: " + rowsAffected);
            return rowsAffected > 0;
        }
    }
    
    public boolean assignRole(String username, String newRole) throws SQLException {
        String query = "UPDATE users SET role = ? WHERE username = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, newRole);
            stmt.setString(2, username);
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        }
    }

}
