package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * AdminHomePage represents the main dashboard for the admin user.
 */
public class AdminHomePage {
    private final DatabaseHelper databaseHelper;
    private final User user;

    public AdminHomePage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
    }

    /**
     * Displays the admin home page.
     * @param primaryStage The primary stage where the scene will be displayed.
     */
    public void show(Stage primaryStage) {
        VBox layout = new VBox(15);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        // Welcome message
        Label adminLabel = new Label("Hello, Admin!");
        adminLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Button to navigate to Question Hub
        Button questionHubButton = new Button("Go to Question Hub");
        questionHubButton.setOnAction(e -> new QuestionHubPage(databaseHelper, user).show(primaryStage));

        // Button to Logout (Optional)
        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> new SetupLoginSelectionPage(databaseHelper).show(primaryStage));

        layout.getChildren().addAll(adminLabel, questionHubButton, logoutButton);
        Scene adminScene = new Scene(layout, 800, 400);

        primaryStage.setScene(adminScene);
        primaryStage.setTitle("Admin Page");
        primaryStage.show();
    }
}