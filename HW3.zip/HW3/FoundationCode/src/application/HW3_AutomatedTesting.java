package application;

import java.sql.SQLException;
import java.util.logging.Logger;
import databasePart1.DatabaseHelper;

/**
 * This class handles automated testing for the database interactions in the HW3 project.
 * It includes tests for user registration, user authentication, role assignment, and question/answer insertion.
 * Each test is logged for success or failure.
 * 
 * @author Isaiah Thomas
 * @version 1.0
 * @since 2025-03-26
 */
public class HW3_AutomatedTesting {

    private static final Logger logger = Logger.getLogger(HW3_AutomatedTesting.class.getName());
    private DatabaseHelper dbHelper;

    /**
     * Main method that initiates the automated testing process.
     * 
     * @param args Command-line arguments (not used in this implementation).
     */
    public static void main(String[] args) {
        HW3_AutomatedTesting tester = new HW3_AutomatedTesting();
        
        try {
            tester.setup();
            tester.testUserRegistration();
            tester.testStudentCanAddQuestion();
            tester.testUserAuthentication();
            //tester.testRoleAssignment();
            tester.testQuestionInsertion();
            tester.tearDown();
        } catch (SQLException e) {
            logger.severe("Test failed due to SQLException: " + e.getMessage());
        }
    }

    /**
     * Initializes the database connection before running the tests.
     * 
     * @throws SQLException If an error occurs while connecting to the database.
     */
    void setup() throws SQLException {
        dbHelper = new DatabaseHelper();
        dbHelper.connectToDatabase();
        logger.info("Database connected successfully ✅.");
    }

    /**
     * Closes the database connection after all tests have been completed.
     * 
     * @throws SQLException If an error occurs while disconnecting from the database.
     */
    void tearDown() throws SQLException {
        dbHelper.closeConnection();
        logger.info("Database disconnected successfully.👋");
    }

    /**
     * Tests the user registration functionality by attempting to register a new user.
     * 
     * @throws SQLException If an error occurs while registering the user.
     */
    void testUserRegistration() throws SQLException {
        User testUser = new User("John", "password123", "student");
        
        boolean isRegistered = dbHelper.register(testUser);
        logTestResult("User Registration", isRegistered);
    }

    /**
     * Tests if a student can successfully add a question to the system.
     * 
     * @throws SQLException If an error occurs while adding the question.
     */
    /**
     * Tests if a student can successfully add a question to the system.
     * 
     * @throws SQLException If an error occurs while adding the question.
     */
    void testStudentCanAddQuestion() throws SQLException {
        String question = "What is the best way to study C++?";
        String answer = "You can study C++ by practicing regularly.";
        String username = "testStudent";
        
        // Check if the user exists, and if not, register the user with a student role
        String existingRole = dbHelper.getUserRole(username);
        if (existingRole == null) {
            // If user doesn't exist, register the user with the student role
            boolean isRegistered = dbHelper.register(new User(username, "password123", "student"));
            if (!isRegistered) {
                System.out.println("User registration failed!");
                return;
            }
        } else if (!"student".equals(existingRole)) {
            // If the user exists but doesn't have a student role, update the role
            boolean isRoleAssigned = dbHelper.assignRole(username, "student");
            if (!isRoleAssigned) {
                System.out.println("Role assignment failed!");
                return;
            }
        }

        // Ensure the user has a student role before adding the question
        String role = dbHelper.getUserRole(username);
        if (!"student".equals(role)) {
            System.out.println("Access Denied: Only students can add questions.");
            return;
        }

        // Add the question
        boolean result = dbHelper.saveQuestion(question, answer);
        logTestResult("Student Ask A Question", result);
    }

    /**
     * Tests the user authentication functionality by registering a user and verifying login credentials.
     * 
     * @throws SQLException If an error occurs while authenticating the user.
     */
    void testUserAuthentication() throws SQLException {
        User testUser = new User("authUser", "securePass", "student");
        dbHelper.register(testUser); // Register the user first
        boolean isAuthenticated = dbHelper.login(testUser); // Attempt login
        logTestResult("User Authentication", isAuthenticated);
    }


    /**
     * Tests the role assignment functionality by assigning a new role to a user.
     * 
     * @throws SQLException If an error occurs while assigning the role.
     */
    void testRoleAssignment() throws SQLException {
        // Register the user with initial role "student"
        dbHelper.register(new User("roleUser", "pass123", "student"));

        // Assign a new role "instructor"
        boolean isRoleAssigned = dbHelper.assignRole("roleUser", "instructor");

        // Verify that the role was successfully updated in the database
        String updatedRole = dbHelper.getUserRole("roleUser");
        boolean testPassed = isRoleAssigned && "instructor".equals(updatedRole);

        logTestResult("Role Assignment", testPassed);
    }


    /**
     * Tests the question insertion functionality by adding a new question to the database.
     * 
     * @throws SQLException If an error occurs while inserting the question.
     */
    void testQuestionInsertion() throws SQLException {
        Question testQuestion = new Question("1", "How do I calculate my grade for this course?");
        boolean isInserted = dbHelper.saveQuestion(testQuestion.getQuestionText(), testQuestion.getAnswer());
        logTestResult("Question Insertion", isInserted);
    }


    /**
     * Logs the result of a test to the logger, indicating whether it passed or failed.
     * 
     * @param testName The name of the test being logged.
     * @param result The result of the test (true if passed, false if failed).
     */
    private void logTestResult(String testName, boolean result) {
        if (result) {
            logger.info(testName + " - PASSED ✅");
        } else {
            logger.warning(testName + " - FAILED ❌");
        }
    }
}
