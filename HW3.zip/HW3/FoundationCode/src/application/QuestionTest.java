package application;

import databasePart1.DatabaseHelper;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
/*
 * This is the questionTest automation page where we automate and test that questions are being able to be added to the database
 * We created a console log where we can run add a question, answer a question, clear an answer, delete a question
 */

public class QuestionTest {
    public static void main(String[] args) {
        DatabaseHelper databaseHelper = new DatabaseHelper();
        Scanner scanner = new Scanner(System.in); //using a scanner for the console log

        try {
            databaseHelper.connectToDatabase();
            
            addHardcodedQuestion(databaseHelper); //also adding a hard coded question to test a question and answer being added
            
            while (true) {
                System.out.println("\n Question & Answer Console");
                System.out.println("1. Add a Question");
                System.out.println("2. Answer a Question");
                System.out.println("3. Clear an Answer");
                System.out.println("4. Delete a Question");
                System.out.println("5. View All Questions & Answers");
                System.out.println("6. View Unanswered Questions");
                System.out.println("7. Exit");
                System.out.print("Choose an option: ");
                
                int choice = scanner.nextInt();
                scanner.nextLine();
                //using a switch case to test the methods from the databasehelper
                switch (choice) {
                    case 1:
                        addQuestion(databaseHelper, scanner);
                        break;
                    case 2:
                        answerQuestion(databaseHelper, scanner);
                        break;
                    case 3:
                        clearAnswer(databaseHelper, scanner);
                        break;
                    case 4:
                        deleteQuestion(databaseHelper, scanner);
                        break;
                    case 5:
                        viewQuestionsAndAnswers(databaseHelper);
                        break;
                    case 6:
                        viewUnansweredQuestions(databaseHelper);
                        break;
                    case 7:
                        System.out.println("Exiting");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        } finally {
            databaseHelper.closeConnection();
            scanner.close();
        }
    }
    //Here we are hard coding a question and answer to be added to the discussion board to test that it is working
    public static void addHardcodedQuestion(DatabaseHelper dbHelper) throws SQLException {
    	String hardcodedQuestion = "What is Quiz 1 going to go over";
    	String hardcodedAnswer = "It is going to go over software principles";
    	
    	List<String> existingQuestions = dbHelper.getQuestions();
    	if(!existingQuestions.contains(hardcodedQuestion)) {
    		dbHelper.saveQuestion(hardcodedQuestion,  hardcodedAnswer);
    		System.out.println("Question and Answer Added");
    	} else {
    		System.out.println("Question already exist");
    	}
    }

    private static void addQuestion(DatabaseHelper dbHelper, Scanner scanner) throws SQLException {
        System.out.print("Enter your question: ");
        String question = scanner.nextLine().trim();
        
        dbHelper.saveQuestion(question, ""); // Save the question with an empty answer
        System.out.println("Question added successfully");
    }

    private static void answerQuestion(DatabaseHelper dbHelper, Scanner scanner) throws SQLException {
        System.out.println("Enter the question you want to answer:");
        String question = scanner.nextLine().trim();

        System.out.print("Enter your answer: ");
        String answer = scanner.nextLine().trim();
        
        dbHelper.updateAnswer(question, answer);
        System.out.println("Answer updated successfully");
    }

    private static void clearAnswer(DatabaseHelper dbHelper, Scanner scanner) throws SQLException {
        System.out.println("Enter the question whose answer you want to clear:");
        String question = scanner.nextLine().trim();
        
        dbHelper.clearAnswer(question);
        System.out.println("Answer cleared successfully.");
    }

    private static void deleteQuestion(DatabaseHelper dbHelper, Scanner scanner) throws SQLException {
        System.out.print("Enter the question to delete: ");
        String question = scanner.nextLine().trim();
        
        dbHelper.deleteQuestion(question);
        System.out.println("Question deleted successfully.");
    }

    private static void viewQuestionsAndAnswers(DatabaseHelper dbHelper) throws SQLException {
        List<String> questionsWithAnswers = dbHelper.getAllQuestionsWithAnswers();

        System.out.println("\n Questions & Answers");
        if (questionsWithAnswers.isEmpty()) {
            System.out.println("No questions found.");
        } else {
            for (String entry : questionsWithAnswers) {
                System.out.println(entry);
                System.out.println("---------------------------");
            }
        }
    }

    private static void viewUnansweredQuestions(DatabaseHelper dbHelper) throws SQLException {
        List<String> unansweredQuestions = dbHelper.getUnansweredQuestions();

        System.out.println("\n Unanswered Questions");
        if (unansweredQuestions.isEmpty()) {
            System.out.println("All questions have answers.");
        } else {
            for (String question : unansweredQuestions) {
                System.out.println(question);
                System.out.println("---------------------------");
            }
        }
    }
}