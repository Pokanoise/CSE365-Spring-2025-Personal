package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * QuestionHubPage represents the admin's question management hub.
 */
public class QuestionHubPage {
    private final DatabaseHelper databaseHelper;
    private final User user;

    public QuestionHubPage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
    }

    /**
     * Displays the question hub page.
     * @param primaryStage The primary stage where the scene will be displayed.
     */
    public void show(Stage primaryStage) {
        VBox layout = new VBox(15);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        // Header label
        Label headerLabel = new Label("Question Hub");
        headerLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Button to navigate to Question Management
        Button manageQuestionsButton = new Button("Manage Questions");
        manageQuestionsButton.setOnAction(e -> new QuestionPage(databaseHelper).show(primaryStage));

        // Button to go back
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new AdminHomePage(databaseHelper, user).show(primaryStage));

        layout.getChildren().addAll(headerLabel, manageQuestionsButton, backButton);
        Scene questionHubScene = new Scene(layout, 800, 400);

        primaryStage.setScene(questionHubScene);
        primaryStage.setTitle("Question Hub");
        primaryStage.show();
    }
}