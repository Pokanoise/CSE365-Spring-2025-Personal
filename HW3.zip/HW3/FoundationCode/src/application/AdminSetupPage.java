package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Modality;

import java.sql.SQLException;

import databasePart1.*;

/**
 * The SetupAdmin class handles the setup process for creating an administrator account.
 * This is intended to be used by the first user to initialize the system with admin credentials.
 */
public class AdminSetupPage {
	
    private final DatabaseHelper databaseHelper;

    public AdminSetupPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
    	
    	//image rendering
    	Image adminFirstUserBG = new Image(getClass().getResourceAsStream("/image/First_User_Admin_Welcome_Page.png"));
		ImageView backgroundView = new ImageView(adminFirstUserBG);
		
		// Adjust ImageView Properties
        backgroundView.setFitWidth(1920);  // Set width 
        backgroundView.setFitHeight(1080); // Set height 
        backgroundView.setPreserveRatio(false); // Stretch to fit

        // StackPane to place image in the background
        StackPane stackPane = new StackPane();
		
    	// Input fields for userName and password
        TextField userNameField = new TextField();
        userNameField.setPromptText("Enter Admin userName");
        userNameField.setMaxWidth(250);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        passwordField.setMaxWidth(250);

        Button setupButton = new Button("Setup");
        
        Button infoButton = new Button("Admin Info");
        
        infoButton.setOnAction(e -> showInfoPopup());
        
        setupButton.setOnAction(a -> {
        	// Retrieve user input
            String userName = userNameField.getText();
            String password = passwordField.getText();
            
            String usernameFeedback = UsernameEvaluator.evaluateUsername(userName);
            if (!usernameFeedback.startsWith("Valid Username")) {
            	showAlert("Username Error", usernameFeedback);
            	return;
            }
            
            String passwordFeedback = PasswordEvaluator.evaluatePassword(password);
            if (!passwordFeedback.startsWith("Valid Password")) {
                showAlert("Password Error", passwordFeedback);
                return;
            }
            try {
            	// Create a new User object with admin role and register in the database
            	User user=new User(userName, password, "admin");
                databaseHelper.register(user);
                System.out.println("Administrator setup completed.");
                
                // Navigate to the Welcome Login Page
                new WelcomeLoginPage(databaseHelper).show(primaryStage,user);
            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
                e.printStackTrace();
            }
        });

        VBox layout = new VBox(10, userNameField, passwordField, setupButton, infoButton);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        
        stackPane.getChildren().addAll(backgroundView,layout);
        primaryStage.setScene(new Scene(stackPane, 1920, 1080));
        primaryStage.setTitle("Administrator Setup1000");
        primaryStage.show();
    }
    /**
     * Display an alert with the given title and message.
     * @param title The title of the alert.
     * @param message The message to display.
     */
    private void showInfoPopup() {
        Stage infoStage = new Stage();
        infoStage.initModality(Modality.APPLICATION_MODAL); // Blocks interaction with main window
        infoStage.setTitle("Information");

        Label infoLabel = new Label("This is an administrator setup page. Please enter your credentials.");
        infoLabel.setWrapText(true);

        // Load an Info Image (Optional)
        Image infoImage = new Image(getClass().getResourceAsStream("/image/Information_Page_Admin.png"));
        ImageView infoImageView = new ImageView(infoImage);
        infoImageView.setFitWidth(1920);
        infoImageView.setFitHeight(1080);
        infoImageView.setPreserveRatio(false);

        VBox infoLayout = new VBox(10, infoImageView, infoLabel);
        infoLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Scene infoScene = new Scene(infoLayout, 1920, 1080);
        infoStage.setScene(infoScene);
        infoStage.show();
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
}