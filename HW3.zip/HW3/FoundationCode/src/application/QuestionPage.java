package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.SQLException;
import java.util.List;

/**
 * This is main discussion board page where the questions can be submitted and viewed. 
 * You can also answers questions that are viewed here
 * You can also clear an answer and then reanswer it.
 * You can also fully just delete a question
 */
public class QuestionPage {
    private final DatabaseHelper databaseHelper;
    private final ListView<String> questionList;
    private final TextField answerField;

    public QuestionPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
        this.questionList = new ListView<>();
        this.answerField = new TextField();
        answerField.setPromptText("Enter your answer");
        answerField.setDisable(true);
    }
// This method is the show method where we build the display where are questions are going to be shown.
   //We also create the buttons on here to be able to submit a question, submit an answer for a question, clear and answer, and delete a question
    public void show(Stage primaryStage) {
        TextField questionField = new TextField();
        questionField.setPromptText("Enter your question");

        Button submitQuestionButton = new Button("Submit Question");
        submitQuestionButton.setOnAction(e -> saveQuestion(questionField.getText()));

        Button submitAnswerButton = new Button("Submit Answer");
        submitAnswerButton.setDisable(true);
        submitAnswerButton.setOnAction(e -> saveAnswer(questionList.getSelectionModel().getSelectedItem(), answerField.getText()));
        
        Button deleteQuestionButton = new Button("Delete Question");
        deleteQuestionButton.setDisable(true);
        
        Button clearAnswerButton = new Button("Clear Answer");
        clearAnswerButton.setDisable(true);
        // this is what is used to click on a question and perform either a submit answer, delete a question, or clear an answer
        questionList.setOnMouseClicked(event -> {
            String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
            System.out.println("Selected Question: " + selectedQuestion); // Prints out in the console to make sure it is taking the question in
            if (selectedQuestion != null) {
                answerField.setDisable(false);
                submitAnswerButton.setDisable(false);
                deleteQuestionButton.setDisable(false);
                clearAnswerButton.setDisable(false);
            }
        });
        
        deleteQuestionButton.setOnAction(e -> {
        	String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
        	if (selectedQuestion != null) {
        		deleteQuestion(selectedQuestion);
        	}
        });
        
        clearAnswerButton.setOnAction(e -> {
        	String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
        	if (selectedQuestion != null) {
        		clearAnswer(selectedQuestion);
        	}
        });
        
        //back button to move user out of the discussion board
        Button backButton = new Button("Return");
        backButton.setOnAction(e -> new UserHomePage().show(primaryStage));
        
        // loads the buttons on to the screen to be used
        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(questionField, submitQuestionButton, questionList, answerField, submitAnswerButton, clearAnswerButton, deleteQuestionButton, backButton);
        
        // This loads the questions to be displayed
        loadQuestions();
        
        // the primary stage display
        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("Discussion Board");
        primaryStage.show();
    }
    
    // method to save a question without an answer into the database. it also reloads the display to it shows in the discussion board
    private void saveQuestion(String question) {
        if (question.isEmpty()) {
            return;
        }
        try {
            databaseHelper.saveQuestion(question, ""); 
            loadQuestions();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    // this saves and answer after clicking on a question without an answer. We also have to edit the question string so the sql injection works
    private void saveAnswer(String question, String answer) {
        if (answer.isEmpty() || question == null) {
            System.out.println("No question selected or empty answer!"); 
            return;
        }

        
        if (question.startsWith("Q: ")) {
            question = question.substring(3); 
        }

        
        if (question.contains("\nA: (No answer yet)")) { //we are getting rid of the extra text so the sql command finds the correct question
            question = question.substring(0, question.indexOf("\nA: (No answer yet)"));
        }

        System.out.println("Saving Answer: Question='" + question + "', Answer='" + answer + "'"); //prints to the console to make sure we are answering the correct question

        try {
            databaseHelper.updateAnswer(question.trim(), answer.trim());
            loadQuestions(); //refreshes the ui to load the answer with the question
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    // load all the questions that are in the h2 data base to be displayed in the UI
    private void loadQuestions() {
        try {
            List<String> questions = databaseHelper.getAllQuestionsWithAnswers();
            questionList.getItems().setAll(questions);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    //this method deletes a question from the database
    private void deleteQuestion(String question) {
    	if (question == null) return;
    	
    	if (question.startsWith("Q: ")) {
    		question = question.substring(3);
    	}
    	if (question.contains("\nA:")) {
    		question = question.substring(0, question.indexOf("\nA:"));
    	}
    	
    	System.out.println("Deleting question: " + question);
    	
    	try {
    		databaseHelper.deleteQuestion(question);
    		loadQuestions();
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
    }
    //this method clears the answer
    private void clearAnswer(String question) {
    	if (question == null) return;
    	
    	if (question.startsWith("Q: ")) {
    		question = question.substring(3);
    	}
    	if (question.contains("\nA:")) {
    		question = question.substring(0, question.indexOf("\nA:"));
    	}
    	
    	System.out.println("Clearing answer for: " + question);
    	
    	try {
    		databaseHelper.clearAnswer(question);
    		loadQuestions();
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
    }
}

