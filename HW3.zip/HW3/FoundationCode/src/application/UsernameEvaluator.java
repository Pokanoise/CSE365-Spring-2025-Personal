package application;

public class UsernameEvaluator {

    /**
     * Validates a username based on predefined rules.
     * @param username The username to validate.
     * @return A message indicating validity or missing requirements.
     */
    public static String evaluateUsername(String username) {
        // Check length constraints
        if (username.length() < 6 || username.length() > 30) {
            return "Username must be between 6 and 30 characters.";
        }

        // Check if username starts with '.' or '-'
        if (username.startsWith(".") || username.startsWith("-")) {
            return "Username cannot start with '.' or '-'.";
        }

        // Flags for checking username requirements
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;
        boolean hasInvalidSequence = false;

        // Allowed special characters
        String allowedSpecialChars = "!$.,()";

        // Iterate through each character in the username
        char prevChar = ' '; // Track previous character to check for ".." or "--"
        for (char ch : username.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(ch)) {
                hasLowercase = true;
            } else if (Character.isDigit(ch)) {
                hasNumber = true;
            } else if (allowedSpecialChars.indexOf(ch) == -1 && ch != '-') {
                // Invalid character detected (not in allowed set)
                return "Username contains invalid characters.";
            }

            // Check for ".." or "--" sequences
            if ((ch == '.' && prevChar == '.') || (ch == '-' && prevChar == '-')) {
                hasInvalidSequence = true;
            }

            prevChar = ch; // Update previous character for next iteration
        }

        // If invalid sequences were found, return an error
        if (hasInvalidSequence) {
            return "Username cannot contain consecutive '..' or '--'.";
        }

        // Collect missing requirements
        StringBuilder feedback = new StringBuilder("Missing requirements: ");
        if (!hasUppercase) feedback.append("Uppercase letter, ");
        if (!hasLowercase) feedback.append("Lowercase letter, ");

        // If any requirement is missing, return feedback
        if (!hasUppercase || !hasLowercase) {
            return feedback.substring(0, feedback.length() - 2); // Remove last comma
        }

        return "Valid Username";
    }
}