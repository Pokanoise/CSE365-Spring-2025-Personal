package application;

public class UsernameAutomationTesting {
    public static void main(String[] args) {
        // Test cases
        String[] testUsernames = {
            "Dbook",          // Too short (invalid)
            "DevinBooker!",      // Valid
            "devinbooker",       // No uppercase (invalid)
            "DEVINBOOKER",       // No lowercase (invalid)
            "Devin.Booker",      // Valid
            ".DevinBooker",      // Starts with '.' (invalid)
            "-DevinBooker",      // Starts with '-' (invalid)
            "Devin..Booker",     // Consecutive '..' (invalid)
            "Devin--Booker",     // Consecutive '--' (invalid)
            "$DevinBooker$",  // Valid
            "DevinBookerKevinDurantShaiAnthonyEdwardsLukaDoncic1!", // Too long (invalid)
        };

        // Run tests
        for (String username : testUsernames) {
            String result = UsernameEvaluator.evaluateUsername(username);
            System.out.println("Username Being Tested: " + username);
            System.out.println();
            System.out.println("Result: " + result);
            System.out.println();
            System.out.println("------------------------------------------------");
        }
    }
}