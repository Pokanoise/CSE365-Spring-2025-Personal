package application;

public class PasswordEvaluator {
    
    /**
     * Checks if the given password meets the security requirements.
     * @param password The password to validate.
     * @return A message indicating the password's strength or missing requirements.
     */
    public static String evaluatePassword(String password) {
        // Check length constraints
        if (password.length() < 8 || password.length() > 30) {
            return "Password must be between 8 and 30 characters.";
        }

        // Flags for checking password requirements
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;

        // Define allowed special characters
        String specialCharacters = "!@#$%^&*()_+-=[]{}|;:'\",.<>?/";

        // Iterate through each character in the password
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(ch)) {
                hasLowercase = true;
            } else if (Character.isDigit(ch)) {
                hasNumber = true;
            } else if (specialCharacters.indexOf(ch) != -1) { // Check if character is in specialCharacters
                hasSpecialChar = true;
            }
        }

        // Collect missing requirements
        StringBuilder feedback = new StringBuilder("Missing requirements: ");
        if (!hasUppercase) feedback.append("Uppercase letter, ");
        if (!hasLowercase) feedback.append("Lowercase letter, ");
        if (!hasNumber) feedback.append("Number, ");
        if (!hasSpecialChar) feedback.append("Special character, ");

        // If any requirement is missing, return feedback
        if (!hasUppercase || !hasLowercase || !hasNumber || !hasSpecialChar) {
            return feedback.substring(0, feedback.length() - 2); // Remove last comma
        }

        // Password strength rating
        if (password.length() >= 8 && password.length() <= 12) {
            return "Valid Password - Strength: Fair";
        } else if (password.length() >= 13 && password.length() <= 20) {
            return "Valid Password - Strength: Strong";
        } else {
            return "Valid Password - Strength: Very Strong";
        }
    }
}