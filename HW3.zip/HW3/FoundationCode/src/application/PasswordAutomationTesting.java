package application;

public class PasswordAutomationTesting {
    public static void main(String[] args) {
        // Test cases
        String[] testPasswords = {
            "Db1!",       // Too short (invalid)
            "devinbooker!1", // No uppercase (invalid)
            "DEVINBOOKER1!", // No lowercase (invalid)
            "DevinBooker@",  // No number (invalid)
            "DevinBooker1",  // No special character (invalid)
            "DevBooker1!",     // Fair (valid)
            "DevinBooker1!#$%", // Strong (valid)
            "DevinBooker!@KevinDurant1&*(", // Very Strong (valid)
            "DevinBooker!@#$KevinDurant&#*$SGA1234AnthonyEdwards" // Too long (invalid)
        };

        // How the passwords are being tested
        for (String password : testPasswords) {
            String result = PasswordEvaluator.evaluatePassword(password);
            System.out.println("Password Being Tested: " + password);
            System.out.println();
            System.out.println("Result: " + result);
            System.out.println();
            System.out.println("------------------------------------------------");
            System.out.println();
        }
    }
}