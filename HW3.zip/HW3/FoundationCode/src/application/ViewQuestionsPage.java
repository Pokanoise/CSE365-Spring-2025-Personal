package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

/**
 * ViewQuestionsPage allows the admin to add questions and answers and view all stored questions.
 */
public class ViewQuestionsPage {
    private final DatabaseHelper databaseHelper;
    private final ListView<String> questionList;

    public ViewQuestionsPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
        this.questionList = new ListView<>();
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label titleLabel = new Label("Admin Question Management");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField questionField = new TextField();
        questionField.setPromptText("Enter a question");

        TextField answerField = new TextField();
        answerField.setPromptText("Enter the answer");

        Button addButton = new Button("Add Question");
        addButton.setOnAction(e -> saveQuestion(questionField.getText(), answerField.getText()));

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new WelcomeLoginPage(databaseHelper).show(primaryStage, new User("", "", "admin")));

        loadQuestions();

        layout.getChildren().addAll(titleLabel, questionField, answerField, addButton, questionList, backButton);
        Scene scene = new Scene(layout, 800, 400);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Admin Question Management");
        primaryStage.show();
    }

    private void saveQuestion(String question, String answer) {
        if (question.isEmpty() || answer.isEmpty()) {
            return; // Prevent empty submissions
        }
        try {
            databaseHelper.saveQuestion(question, answer);
            loadQuestions(); // Refresh the list
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadQuestions() {
        try {
            List<String> questions = databaseHelper.getQuestions();
            questionList.getItems().setAll(questions);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}