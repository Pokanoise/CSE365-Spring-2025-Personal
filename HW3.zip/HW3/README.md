This code now has our CRUD operations. We accomplished this task by adding a Question.java, Questions.java, Answer.java, Answers.java, and QuestionPage.java. This now shows our discussion board page as well as being able add questions and answers to it.

Here we have our screencast linked as well.

This screencast goes over the code and explaing how the methods actually accomplish the CRUD operations.

https://asu.zoom.us/rec/share/g3TA7cFr4qXFatNUl4i5WJrWtojlEPprn7ia1v0ZZRDgRIyTfN3AsHQ_Ym6LHuEY.85Fx6KR1Uk1234ub
Passcode: %0SgCP?Y


This screencast goes over the automated testing as well as the manual testing showing how the CRUD operations are implemented in the application

https://asu.zoom.us/rec/share/vfq0JOHB4u9mi7bjAQ4sqXzLbBj-jUQPWb3kYrPCcPCrrm9olkDaC2aooaVt2vqi.KIZVracG4-00Mo-y
Passcode: j5.+N3Xs
