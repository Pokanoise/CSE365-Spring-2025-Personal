package databasePart1;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;

import application.StaffMessage;
import application.User;


/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 */
public class DatabaseHelper {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/test";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	private Connection connection = null;
	private Statement statement = null; 
	//	PreparedStatement pstmt

	public boolean connectToDatabase() throws SQLException {
        try {
            Class.forName(JDBC_DRIVER); // Load the JDBC driver
            System.out.println("Connecting to database...");
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            statement = connection.createStatement(); 
            // You can use this command to clear the database and restart from fresh.
            //statement.execute("DROP ALL OBJECTS");
            
            createTables();  // Create the necessary tables if they don't exist
            return true;
            
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
            return false;
        }
    }

	private void createTables() throws SQLException {
		String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, "
				+ "password VARCHAR(255), "
				+ "role VARCHAR(20), "
				+ "isBanned BOOLEAN DEFAULT FALSE)";
		
		statement.execute(userTable);
		
		// Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	            + "isUsed BOOLEAN DEFAULT FALSE)";
	    statement.execute(invitationCodesTable);
	
	    String questionsTable = "CREATE TABLE IF NOT EXISTS questions ("
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "question_text TEXT NOT NULL, "
	            + "answer_text TEXT NULL, "
	            + "userName VARCHAR(255), "
	            + "answerer VARCHAR(255))";
	    statement.execute(questionsTable);
	    
	    String privateMessagesTable = "CREATE TABLE IF NOT EXISTS private_messages ("
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "sender VARCHAR(255), "
	            + "recipient VARCHAR(255), "
	            + "message TEXT, "
	            + "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
	    statement.execute(privateMessagesTable);
	    
	    String trustedTable = "CREATE TABLE IF NOT EXISTS trusted_reviewers (" +
	            "student VARCHAR(255), " +
	            "reviewer VARCHAR(255), " +
	            "PRIMARY KEY (student, reviewer))";
	    statement.execute(trustedTable);
	  
	    
	}
	
	


	// Check if the database is empty
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	// Registers a new user in the database.
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO cse360users (userName, password, role) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.executeUpdate();
		}
	}

	// Validates a user's login credentials.
	public boolean login(User user) throws SQLException {
		String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ? AND role = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}
	
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}
	
	// Retrieves the role of a user from the database using their UserName.
	public String getUserRole(String userName) {
	    String query = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("role"); // Return the role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode() {
	    String code = UUID.randomUUID().toString().substring(0, 4); // Generate a random 4-character code
	    String query = "INSERT INTO InvitationCodes (code) VALUES (?)";

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
	}
	
	// Validates an invitation code to check if it is unused.
	public boolean validateInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            // Mark the code as used
	            markInvitationCodeAsUsed(code);
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	// Marks the invitation code as used in the database.
	private void markInvitationCodeAsUsed(String code) {
	    String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	// Closes the database connection and statement.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}
	// Resets all users in the database (if you want a complete reset)
	public void resetDatabase() throws SQLException {
	    String sql = "DELETE FROM cse360users";  // Correct table name
	    try (Statement stmt = connection.createStatement()) {
	        stmt.executeUpdate(sql);
	    }
	}
	// Deletes all users from the database
	public void resetAllUsers() throws SQLException {
	    String sql = "DELETE FROM cse360users";
	    try (Statement stmt = connection.createStatement()) {
	        stmt.executeUpdate(sql);
	        System.out.println("All users have been deleted from the database.");
	    }
	}

	// Resets only the admin account
	public void resetAdmin() throws SQLException {
	    String sql = "DELETE FROM cse360users WHERE role = 'admin'";
	    try (Statement stmt = connection.createStatement()) {
	        stmt.executeUpdate(sql);
	    }
	}
	// Saves a question along with the username of the creator
	public boolean saveQuestion(String question, String answers, String userName) throws SQLException {
	    String query = "INSERT INTO questions (question_text, answer_text, userName) VALUES (?, ?, ?)";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, question);
	        stmt.setString(2, answers);
	        stmt.setString(3, userName); // Track the owner of the question
	        stmt.executeUpdate();
	        return true;
	    }
	}
	
	
	public List<String> getQuestions() throws SQLException {
	    List<String> questions = new ArrayList<>();
	    String query = "SELECT question_text FROM questions";
	    
	    try (Statement stmt = connection.createStatement();
	         ResultSet rs = stmt.executeQuery(query)) {
	        while (rs.next()) {
	            questions.add(rs.getString("question_text"));
	        }
	    }
	    return questions;
	}
	public List<String> getAnswers() throws SQLException {
		List<String> answers = new ArrayList<>();
		String query = "SELECT answer_text FROM questions";
		
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {
					while (rs.next()) {
						answers.add(rs.getString("answer_text"));
					}
				}
				return answers;
	}
	
    public List<String> getQuestionsWithAnswers() throws SQLException {
        List<String> questionsWithAnswers = new ArrayList<>();
        String query = "SELECT question_text, answer_text FROM questions";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String question = rs.getString("question_text");
                String answer = rs.getString("answer_text");
                questionsWithAnswers.add("Q: " + question + "\nA: " + answer);
            }
        }
        return questionsWithAnswers;
    }
    
    public List<String> getUnansweredQuestions() throws SQLException {
        List<String> questions = new ArrayList<>();
        String query = "SELECT question_text FROM questions WHERE answer_text = ''";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                questions.add("Q: " + rs.getString("question_text"));
            }
        }
        return questions;
    }
    
    public boolean updateAnswer(String question, String answer) throws SQLException {
        String sql = "UPDATE questions SET ANSWER_TEXT = ? WHERE QUESTION_TEXT = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, answer);
            stmt.setString(2, question);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("SQL Executed: " + stmt.toString()); // Debugging log
            System.out.println("Rows updated: " + rowsAffected); // Debugging log
            return true;
        }
    }

    
    public List<String> getAllQuestionsWithAnswers() throws SQLException {
        List<String> questionsWithAnswers = new ArrayList<>();
        String query = "SELECT question_text, answer_text, userName, answerer FROM questions";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String question = rs.getString("question_text");
                String answer = rs.getString("answer_text");
                String asker = rs.getString("userName");
                String answerer = rs.getString("answerer");

                StringBuilder entry = new StringBuilder();
                entry.append("Q: ").append(question);
                if (asker != null && !asker.trim().isEmpty()) {
                    entry.append(" (by ").append(asker).append(")");
                }

                if (answer == null || answer.trim().isEmpty()) {
                    entry.append("\nA: (No answer yet)");
                } else {
                    entry.append("\nA: ").append(answer);
                    if (answerer != null && !answerer.trim().isEmpty()) {
                        entry.append(" (by ").append(answerer).append(")");
                    }
                }

                questionsWithAnswers.add(entry.toString());
            }
        }
        return questionsWithAnswers;
    }
    
    public boolean deleteQuestion(String question) throws SQLException {
    	String sql = "DELETE FROM questions WHERE QUESTION_TEXT = ?";
    	
    	try (PreparedStatement stmt = connection.prepareStatement(sql)) {
    		stmt.setString(1, question.trim());
    		int rowsAffected = stmt.executeUpdate();
    		System.out.println("Deleted Question: " + question + ", Rows affected: " + rowsAffected);
    		return true;
    	}
    }
    
    public void clearAnswer(String question) throws SQLException {
    	String sql = "UPDATE questions SET ANSWER_TEXT = NULL WHERE QUESTION_TEXT = ?";
    	
    	try(PreparedStatement stmt = connection.prepareStatement(sql)) {
    		stmt.setString(1, question.trim());
    		int rowsAffected = stmt.executeUpdate();
    		System.out.println("Cleared Answer for Question: " + question + ", Rows affected: " + rowsAffected);
    	}
    }
    
 // Updates the answer with role-based permission checks
    public boolean updateAnswerWithRole(String question, String newAnswer, String role, String userName) throws SQLException {
        // Admin and Reviewer can update any question
        if (role.equals("admin") || role.equals("reviewer")) {
            String sql = "UPDATE questions SET answer_text = ?, answerer = ? WHERE question_text = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, newAnswer);
                stmt.setString(2, userName); // set the answerer
                stmt.setString(3, question);
                int rowsAffected = stmt.executeUpdate();
                System.out.println("Admin/Reviewer updated question: " + question);
                return rowsAffected > 0;
            }
        }

        // Student can only update their own question
        if (role.equals("student")) {
            // Check if the question belongs to the student
            String ownerQuery = "SELECT userName FROM questions WHERE question_text = ?";
            try (PreparedStatement ownerStmt = connection.prepareStatement(ownerQuery)) {
                ownerStmt.setString(1, question);
                ResultSet rs = ownerStmt.executeQuery();
                if (rs.next()) {
                    String owner = rs.getString("userName");
                    if (!owner.equals(userName)) {
                        System.out.println("Access Denied: Student can only update their own questions.");
                        return false;
                    }
                }
            }

            // Update the question if it belongs to the student
            String sql = "UPDATE questions SET answer_text = ?, answerer = ? WHERE question_text = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, newAnswer);
                stmt.setString(2, userName); // set the answerer
                stmt.setString(3, question);
                int rowsAffected = stmt.executeUpdate();
                System.out.println("Student updated their own question: " + question);
                return rowsAffected > 0;
            }
        }

        return false; // If role is not recognized
    }
    
    public boolean deleteQuestionWithRole(String question, String role) throws SQLException {
        // Check for valid roles: only admin can delete
        if (!role.equals("admin")) {
            System.out.println("Access Denied: Only admins can delete questions.");
            return false;
        }

        String sql = "DELETE FROM questions WHERE question_text = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, question);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Role-based delete (Role: " + role + "): Rows deleted: " + rowsAffected);
            return rowsAffected > 0;
        }
    }
    
 // Retrieves the currently logged-in user's username
    public String getLoggedInUserName() throws SQLException {
        String query = "SELECT userName FROM cse360users WHERE isLoggedIn = TRUE";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getString("userName");
            }
        }
        return "Anonymous";
    }
    
 // Sets the logged-in status for the given username
    public void setLoggedIn(String userName) throws SQLException {
        // First, reset all users to logged out
        String resetQuery = "UPDATE cse360users SET isLoggedIn = FALSE";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(resetQuery);
        }

        // Now set the logged-in status for the specified user
        String updateQuery = "UPDATE cse360users SET isLoggedIn = TRUE WHERE userName = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(updateQuery)) {
            pstmt.setString(1, userName);
            pstmt.executeUpdate();
            System.out.println("User " + userName + " is now logged in.");
        }
    }
    
    
 // Logs out all users
    public void logoutAllUsers() throws SQLException {
        String query = "UPDATE cse360users SET isLoggedIn = FALSE";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("All users logged out.");
        }
    }
    
 // Saves a question along with the username and role
    public boolean saveQuestionWithRole(String question, String answer, String role) throws SQLException {
        // Ensure only valid roles can add questions
        if (!role.equals("admin") && !role.equals("reviewer") && !role.equals("student")) {
            System.out.println("Access Denied: Only admin, reviewer, or student can add a question.");
            return false;
        }

        String query = "INSERT INTO questions (question_text, answer_text, userName) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, question);
            stmt.setString(2, answer);
            stmt.setString(3, role); // Use role as the owner
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Question added by " + role + ": " + question);
            return rowsAffected > 0;
        }
    }
 // Deletes an answer with role-based permission checks
    public boolean deleteAnswerWithRole(String question, String role) throws SQLException {
        // Ensure only reviewer or admin can delete an answer
        if (!role.equals("admin") && !role.equals("reviewer")) {
            System.out.println("Access Denied: Only admin or reviewer can delete an answer.");
            return false;
        }

        String query = "UPDATE questions SET answer_text = NULL WHERE question_text = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, question);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Answer deleted by " + role + ": " + question);
            return rowsAffected > 0;
        }
    }
    
    public void sendPrivateMessage(String sender, String recipient, String message) throws SQLException {
        String query = "INSERT INTO private_messages (sender, recipient, message) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, sender);
            stmt.setString(2, recipient);
            stmt.setString(3, message);
            stmt.executeUpdate();
        }
    }
    
    public List<String> getMessagesForUser(String username) throws SQLException {
        List<String> messages = new ArrayList<>();
        String query = "SELECT sender, message, timestamp FROM private_messages WHERE recipient = ? ORDER BY timestamp DESC";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String sender = rs.getString("sender");
                String message = rs.getString("message");
                Timestamp timestamp = rs.getTimestamp("timestamp");
                messages.add("From: " + sender + " | " + timestamp + "\n" + message + "\n");
            }
        }

        return messages;
    }
    
    public List<String> getAllUsernamesExcept(String currentUser) throws SQLException {
        List<String> usernames = new ArrayList<>();
        String query = "SELECT userName FROM cse360users WHERE userName <> ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, currentUser);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                usernames.add(rs.getString("userName"));
            }
        }

        return usernames;
    }
    
    public void saveReview(String reviewer, String question, String answer, String reviewText) throws SQLException {
        String query = "INSERT INTO reviews (reviewer, question, answer, review) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, reviewer);
            stmt.setString(2, question);
            stmt.setString(3, answer);
            stmt.setString(4, reviewText);
            stmt.executeUpdate();
        }
    }
    
    public List<String> getReviewsByReviewer(String reviewer) throws SQLException {
        List<String> reviews = new ArrayList<>();
        String query = "SELECT id, question, answer, review FROM reviews WHERE reviewer = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, reviewer);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String question = rs.getString("question");
                String answer = rs.getString("answer");
                String review = rs.getString("review");
                int id = rs.getInt("id");
                reviews.add("Review ID: " + id + "\nQ: " + question + "\nA: " + answer + "\nReview: " + review);
            }
        }
        return reviews;
    }
    
    public boolean updateReview(int reviewId, String newReviewText) throws SQLException {
        String query = "UPDATE reviews SET review = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, newReviewText);
            stmt.setInt(2, reviewId);
            return stmt.executeUpdate() > 0;
        }
    }
    
    public boolean deleteReview(int reviewId) throws SQLException {
        String query = "DELETE FROM reviews WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, reviewId);
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<String> getAllReviews() throws SQLException {
        List<String> reviews = new ArrayList<>();
        String query = "SELECT reviewer, question, answer, review FROM reviews";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String reviewer = rs.getString("reviewer");
                String question = rs.getString("question");
                String answer = rs.getString("answer");
                String review = rs.getString("review");
                reviews.add("Reviewer: " + reviewer + "\nQ: " + question + "\nA: " + answer + "\nReview: " + review);
            }
        }
        return reviews;
    }
    
    public void markQuestionForReview(String questionText) throws SQLException {
        String query = "UPDATE questions SET markedForReview = TRUE WHERE question_text = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, questionText.trim());
            stmt.executeUpdate();
        }
    }
    
    public List<String> getQuestionsMarkedForReview() throws SQLException {
        List<String> reviewItems = new ArrayList<>();
        String query = "SELECT question_text, answer_text, userName, answerer FROM questions WHERE markedForReview = TRUE";

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String q = rs.getString("question_text");
                String a = rs.getString("answer_text");
                String asker = rs.getString("userName");
                String answerer = rs.getString("answerer");

                if (a == null || a.trim().isEmpty()) {
                    a = "(No answer yet)";
                }
                if (answerer == null) {
                    answerer = "(unknown)";
                }

                reviewItems.add("Q: " + q + "\nBy: " + asker + "\nA: " + a + "\nAnswered By: " + answerer);
            }
        }

        return reviewItems;
    }
    
    public void addTrustedReviewer(String studentUsername, String rawReviewerString) throws SQLException {
        // Clean reviewer name: strip off everything after "Q:"
        String reviewerUsername = rawReviewerString;
        int qIndex = reviewerUsername.indexOf("Q:");
        if (qIndex != -1) {
            reviewerUsername = reviewerUsername.substring(0, qIndex).trim();
        }

        System.out.println("✅ Cleaned reviewer username: [" + reviewerUsername + "]");

        // Now add to trusted_reviewers with default weight of 0
        String sql = "MERGE INTO trusted_reviewers (student, reviewer, weight) KEY(student, reviewer) VALUES (?, ?, 0)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, studentUsername.trim());
            stmt.setString(2, reviewerUsername.trim());
            stmt.executeUpdate();
        }
    }
    
    public void updateReviewerWeight(String student, String reviewer, int weight) throws SQLException {
        String sql = "UPDATE trusted_reviewers SET weight = ? WHERE student = ? AND reviewer = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, weight);
            stmt.setString(2, student.trim());
            stmt.setString(3, reviewer.trim());
            stmt.executeUpdate();
        }
    }
    
    public List<String> getReviewsFromTrustedReviewers(String student) throws SQLException {
        List<String> reviews = new ArrayList<>();

        String sql = """
            SELECT r.id, r.reviewer, r.question, r.answer, r.review
            FROM reviews r
            JOIN trusted_reviewers t ON r.reviewer = t.reviewer
            WHERE t.student = ?
            ORDER BY t.weight DESC
        """;

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, student.trim());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String formatted = "Review ID: " + rs.getInt("id") +
                        " | Reviewer: " + rs.getString("reviewer") +
                        " | Question: " + rs.getString("question") +
                        " | Answer: " + rs.getString("answer") +
                        " | Review: " + rs.getString("review");
                reviews.add(formatted);
            }
        }

        return reviews;
    }
    
    public boolean sendReviewerRequest(String studentUsername) throws SQLException {
        String sql = "MERGE INTO reviewer_requests (student) KEY(student) VALUES (?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, studentUsername);
            stmt.executeUpdate();
            return true;
        }
    }
    
    public List<String> getStudentsRequestingReviewer() throws SQLException {
        List<String> students = new ArrayList<>();
        String sql = "SELECT student FROM reviewer_requests";

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                students.add(rs.getString("student"));
            }
        }
        return students;
    }
    
    public List<String> getQuestionsAndAnswersByStudent(String student) throws SQLException {
        List<String> qaList = new ArrayList<>();
        String sql = "SELECT question_text, answer_text FROM questions WHERE userName = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, student);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String question = rs.getString("question_text");
                String answer = rs.getString("answer_text");
                if (answer == null || answer.trim().isEmpty()) {
                    answer = "(No answer yet)";
                }
                qaList.add("Q: " + question + "\nA: " + answer);
            }
        }
        return qaList;
    }
    
    public void promoteToReviewer(String student) throws SQLException {
        String sql = "UPDATE cse360users SET role = 'reviewer' WHERE userName = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, student);
            stmt.executeUpdate();
        }
    }
    
    public void removeReviewerRequest(String student) throws SQLException {
        String sql = "DELETE FROM reviewer_requests WHERE student = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, student);
            stmt.executeUpdate();
        }
    }

 // Create user if not exists
    public void createUserIfNotExists(String username, String password, String role) throws SQLException {
        String sql = "MERGE INTO cse360users (username, password, role) KEY(username) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, role);
            stmt.executeUpdate();
        }
    }
    
    // ********** HW4 *************
    
    // User Moderation
    
    public void banUser(String userName) throws SQLException {
        String sql = "UPDATE cse360users SET isBanned = TRUE WHERE userName = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, userName);
            stmt.executeUpdate();
        }
    }
    
    public void unbanUser(String username) throws SQLException {
    	String sql = "UPDATE cse360users SET isBanned = FALSE WHERE userName = ?";
    	try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        }
    }

    public boolean isUserBanned(String userName) throws SQLException {
        String sql = "SELECT isBanned FROM cse360users WHERE userName = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, userName);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getBoolean("isBanned");
        }
    }
    
    public List<String> getBannedUsers() throws SQLException {
        List<String> bannedUsers = new ArrayList<>();
        String sql = "SELECT userName FROM cse360users WHERE isBanned = TRUE";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                bannedUsers.add(rs.getString("userName"));
            }
        }
        return bannedUsers;
    }

    
    // Staff Chat
    
    public void sendStaffMessage(String sender, String message) throws SQLException {
        String sql = "INSERT INTO staff_messages (sender, message) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, sender);
            stmt.setString(2, message);
            stmt.executeUpdate();
        }
    }

    public List<StaffMessage> getStaffMessages() throws SQLException {
        List<StaffMessage> messages = new ArrayList<>();
        String sql = "SELECT sender, message, timestamp FROM staff_messages ORDER BY timestamp ASC";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String sender = rs.getString("sender");
                String message = rs.getString("message");
                String timestamp = rs.getTimestamp("timestamp").toString();
                messages.add(new StaffMessage(sender, message, timestamp));
            }
        }
        return messages;
    }

    
    // Feedback Panel
    
    public void submitFeedback(String submittedBy, String content, String category) throws SQLException {
        String sql = "INSERT INTO feedback (submittedBy, content, category) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, submittedBy);
            stmt.setString(2, content);
            stmt.setString(3, category);
            stmt.executeUpdate();
        }
    }

    public List<String> getAllFeedback() throws SQLException {
        List<String> feedbackList = new ArrayList<>();
        String sql = "SELECT submittedBy, content, category, timestamp FROM feedback ORDER BY timestamp DESC";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                feedbackList.add("[" + rs.getString("category") + "] " +
                    rs.getString("content") + " - " + rs.getString("submittedBy") + 
                    " (" + rs.getTimestamp("timestamp") + ")");
            }
        }
        return feedbackList;
    }

    public List<String> getFeedbackByCategory(String category) throws SQLException {
        List<String> feedbackList = new ArrayList<>();
        String sql;

        if (category.equals("All")) {
            sql = "SELECT submittedBy, content, category, timestamp FROM feedback ORDER BY timestamp DESC";
            try (PreparedStatement stmt = connection.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    feedbackList.add("[" + rs.getString("category") + "] " +
                        rs.getString("content") + " - " + rs.getString("submittedBy") +
                        " (" + rs.getTimestamp("timestamp") + ")");
                }
            }
        } else {
            sql = "SELECT submittedBy, content, timestamp FROM feedback WHERE category = ? ORDER BY timestamp DESC";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, category);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    feedbackList.add(rs.getString("content") +
                        " - " + rs.getString("submittedBy") +
                        " (" + rs.getTimestamp("timestamp") + ")");
                }
            }
        }

        return feedbackList;
    }

    // Flagged Content
    public void flagContent(String flaggedBy, String content, String reason) throws SQLException {
        String sql = "INSERT INTO flagged_content (flaggedBy, content, reason) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, flaggedBy);
            stmt.setString(2, content);
            stmt.setString(3, reason);
            stmt.executeUpdate();
        }
    }

    public List<String> getFlaggedContent() throws SQLException {
        List<String> flags = new ArrayList<>();
        String sql = "SELECT flaggedBy, content, reason, timestamp FROM flagged_content ORDER BY timestamp DESC";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                flags.add("⚠️ Flagged by " + rs.getString("flaggedBy") +
                          " | Reason: " + rs.getString("reason") +
                          " | " + rs.getTimestamp("timestamp") +
                          "\nContent: " + rs.getString("content"));
            }
        }
        return flags;
    }


}
