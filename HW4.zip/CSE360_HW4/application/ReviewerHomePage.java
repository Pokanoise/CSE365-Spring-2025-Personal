package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * ReviewerHomePage.java
 * Reviewer landing page after login.
 * Allows navigation to private messaging, discussion board, and logout.
 */
public class ReviewerHomePage {

    private final DatabaseHelper databaseHelper;
    private final User reviewer;

    public ReviewerHomePage(DatabaseHelper databaseHelper, User reviewer) {
        this.databaseHelper = databaseHelper;
        this.reviewer = reviewer;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(15);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label welcomeLabel = new Label("Welcome Reviewer: " + reviewer.getUserName());

        Button messagesButton = new Button("View Private Messages");
        messagesButton.setOnAction(e -> new PrivateMessaging(databaseHelper, reviewer).show(primaryStage));

        Button discussionBoardButton = new Button("Go to Discussion Board");
        discussionBoardButton.setOnAction(e -> new QuestionPage(databaseHelper).show(primaryStage));

        // ✅ Add Manage Reviews Button
        Button manageReviewsButton = new Button("Manage Reviews");
        manageReviewsButton.setOnAction(e -> new ReviewPage(databaseHelper, reviewer).show(primaryStage));

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> new SetupLoginSelectionPage(databaseHelper).show(primaryStage));

        // Add all buttons to layout
        layout.getChildren().addAll(
            welcomeLabel,
            messagesButton,
            discussionBoardButton,
            manageReviewsButton,  // ✅ Add it here too
            logoutButton
        );

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Reviewer Home Page");
        primaryStage.show();
    }
}