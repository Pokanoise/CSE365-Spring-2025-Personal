package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

/**
 * StudentReviewList.java
 * Allows students to browse all reviews and mark specific reviewers as trusted.
 */
public class StudentReviewList {

    private final DatabaseHelper databaseHelper;
    private final User student;

    public StudentReviewList(DatabaseHelper databaseHelper, User student) {
        this.databaseHelper = databaseHelper;
        this.student = student;
    }

    public void show(Stage primaryStage) {
        Label header = new Label("Browse Reviews");
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ListView<String> reviewListView = new ListView<>();
        loadAllReviews(reviewListView);

        Button markTrustedBtn = new Button("Mark as Trusted Reviewer");
        markTrustedBtn.setOnAction(e -> {
            String selectedReview = reviewListView.getSelectionModel().getSelectedItem();
            if (selectedReview != null && selectedReview.contains("Reviewer: ")) {
                String reviewer = extractReviewerUsername(selectedReview);
                try {
                    databaseHelper.addTrustedReviewer(student.getUserName(), reviewer);
                    showAlert("Marked " + reviewer + " as a trusted reviewer.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    showAlert("Error marking reviewer as trusted.");
                }
            }
        });

        Button returnBtn = new Button("Return");
        returnBtn.setOnAction(e -> new StudentHomePage(databaseHelper, student).show(primaryStage));

        VBox layout = new VBox(10, header, reviewListView, markTrustedBtn, returnBtn);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        primaryStage.setScene(new Scene(layout, 800, 500));
        primaryStage.setTitle("Student Review List");
        primaryStage.show();
    }

    private void loadAllReviews(ListView<String> listView) {
        try {
            List<String> reviews = databaseHelper.getAllReviews(); // assumes this method exists
            listView.getItems().setAll(reviews);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String extractReviewerUsername(String reviewText) {
        // Looks for "Reviewer: username" in a longer review string
        int start = reviewText.indexOf("Reviewer: ");
        if (start == -1) return null;

        int end = reviewText.indexOf(" |", start); // Find the end of reviewer name
        if (end == -1) end = reviewText.length();  // In case there's no separator after reviewer

        return reviewText.substring(start + "Reviewer: ".length(), end).trim();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}