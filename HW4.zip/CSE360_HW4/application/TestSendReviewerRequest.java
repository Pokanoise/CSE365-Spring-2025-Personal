package application;

import java.sql.SQLException;
import java.util.logging.Logger;
import databasePart1.DatabaseHelper;
import java.sql.SQLException;


/**
 * This class handles automated testing for the database interactions in the HW3 project.
 * It includes tests for user registration, user authentication, role assignment, and question/answer insertion.
 * Each test is logged for success or failure.
 * 
 * @author Team30
 * @version 1.0
 * @since 2025-03-26
 */
public class TestSendReviewerRequest {

    private static final Logger logger = Logger.getLogger(TestSendReviewerRequest.class.getName());
    private DatabaseHelper dbHelper;

    public static void main(String[] args) {
        TestSendReviewerRequest tester = new TestSendReviewerRequest();
        
        try {
            tester.setup();
            tester.testStudentCanAddQuestion();
            tester.testAdminCanAddQuestion();
            tester.testReviewerCanAddQuestion();
            tester.testReviewerCanDeleteAnswer();
            tester.testReviewerCanAnswerQuestion();
            tester.testStudentAnswer();
            tester.testAdminAnswer();
            tester.testReviewerAnswer();
            tester.testStudentDeletesQuestion();
            tester.testStudentDeletesAnswer();
            tester.testPassword();
            tester.testDatabaseConnection();
            tester.testStudentAddQuestion();
            tester.tearDown();
        } catch (SQLException e) {
            logger.severe("Test failed due to SQLException: " + e.getMessage());
        }
    }

    void setup() throws SQLException {
        dbHelper = new DatabaseHelper();
        dbHelper.connectToDatabase();
        logger.info("Database connected successfully.");
    }

    void tearDown() throws SQLException {
        dbHelper.closeConnection();
        logger.info("Database disconnected successfully.");
    }

    void testPassword() {
        String[][] testCases = {
            {"Db1!", "Invalid – Too Short"},
            {"devinbooker!1", "Invalid – Missing Uppercase"},
            {"DevBooker1!", "Valid – Fair"},
            {"DevinBooker!@KevinDurant1&*(", "Valid – Very Strong"},
            {"DevinBooker!@#$KevinDurant&#*$SGA1234AnthonyEdwards", "Invalid – Too Long"}
        };

        int passedCount = 0;
        for (String[] testCase : testCases) {
            String password = testCase[0];
            String expected = testCase[1];
            String actual = PasswordEvaluator.evaluatePassword(password);
            boolean passed = expected.equals(actual);
            if (passed) passedCount++;
            System.out.println("Password Test: " + (passed ? "PASSED" : "FAILED") + " | " + password);
        }
        System.out.println("Password Tests Passed: " + passedCount + "/" + testCases.length);
    }

    void testDatabaseConnection() throws SQLException {
        boolean isConnected = dbHelper.connectToDatabase();
        logTestResult("Database Connection", isConnected);
    }

    void testStudentCanAddQuestion() throws SQLException {
        boolean result = dbHelper.saveQuestion("What is OOP?", "Object-Oriented Programming", "TestStudent");
        logTestResult("Student Add Question", result);
    }

    void testAdminCanAddQuestion() throws SQLException {
        boolean result = dbHelper.saveQuestion("What is SQL?", "Structured Query Language", "TestAdmin");
        logTestResult("Admin Add Question", result);
    }

    void testReviewerCanAddQuestion() throws SQLException {
        boolean result = dbHelper.saveQuestion("Explain indexing in databases?", "Indexing improves search speed.","TestReviewer");
        logTestResult("Reviewer Add Question", result);
    }

    void testReviewerCanDeleteAnswer() throws SQLException {
    	dbHelper.saveQuestion("What is the best way to study for C++", "Watching a video","TestStudent");
        boolean result = dbHelper.deleteAnswerWithRole("What is the best way to study for C++", "Reviewer");
        logTestResult("Reviewer Delete Answer", result);
    }

    void testReviewerCanAnswerQuestion() throws SQLException {
    	dbHelper.saveQuestion("Why is important to index", null, "Reviewer");
        boolean result = dbHelper.updateAnswer("Why is important to index", "Indexing helps optimize database queries.");
        logTestResult("Reviewer Answer Question", result);
    }

    void testStudentAnswer() throws SQLException {
    	dbHelper.saveQuestion("What is OOP", null, null);
        boolean result = dbHelper.updateAnswer("What is OOP","Encapsulation, Inheritance, Polymorphism, Abstraction");
        logTestResult("Student Answer", result);
    }

    void testAdminAnswer() throws SQLException {
    	dbHelper.saveQuestion("What is SQL",null,null);
        boolean result = dbHelper.updateAnswer("What is SQL?", "SQL is used to interact with databases.");
        logTestResult("Admin Answer", result);
    }

    void testReviewerAnswer() throws SQLException {
    	dbHelper.saveQuestion("Why is indexing important?", null, null);
        boolean result = dbHelper.updateAnswer("Why is indexing important?", "Indexing reduces query time complexity.");
        logTestResult("Reviewer Answer", result);
    }

    void testStudentDeletesQuestion() throws SQLException {
    	dbHelper.saveQuestion("What is point of engineering?",null,null);
        boolean result = dbHelper.deleteQuestion("What is point of engineering?");
        logTestResult("Student Delete Question", result);
    }

    void testStudentDeletesAnswer() throws SQLException {
    	dbHelper.saveQuestion("How do we get the best grade in 360",null,null);
        boolean result = dbHelper.deleteAnswerWithRole("How do we get the best grade in 360","Student");
        logTestResult("Student Delete Answer", result);
    }

    void testStudentAddQuestion() throws SQLException {
        boolean result = dbHelper.saveQuestion("How does Java handle memory management?", "Garbage collection","TestStudent");
        logTestResult("Student Add Question", result);
    }

    private void logTestResult(String testName, boolean result) {
        if (result) {
            logger.info(testName + " - PASSED");
        } else {
            logger.warning(testName + " - FAILED");
        }
    }
}