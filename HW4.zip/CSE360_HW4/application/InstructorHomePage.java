package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * InstructorHomePage.java
 * Instructor landing page after login.
 * Allows navigation to private messaging, discussion board, and logout.
 */
public class InstructorHomePage {

    private final DatabaseHelper databaseHelper;
    private final User instructor;

    public InstructorHomePage(DatabaseHelper databaseHelper, User instructor) {
        this.databaseHelper = databaseHelper;
        this.instructor = instructor;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(15);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label welcomeLabel = new Label("Welcome Instructor: " + instructor.getUserName());

        Button messagesButton = new Button("View Private Messages");
        messagesButton.setOnAction(e -> new PrivateMessaging(databaseHelper, instructor).show(primaryStage));

        Button discussionBoardButton = new Button("Go to Discussion Board");
        discussionBoardButton.setOnAction(e -> new QuestionPage(databaseHelper).show(primaryStage));
        
     // ✅ NEW: Button to review student reviewer requests
        Button reviewRequestsButton = new Button("Review Student Reviewer Requests");
        reviewRequestsButton.setOnAction(e -> new ReviewerRequestPage(databaseHelper, instructor).show(primaryStage));

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> new SetupLoginSelectionPage(databaseHelper).show(primaryStage));

        layout.getChildren().addAll(welcomeLabel, messagesButton, discussionBoardButton, reviewRequestsButton, logoutButton);

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Instructor Home Page");
        primaryStage.show();
    }
}