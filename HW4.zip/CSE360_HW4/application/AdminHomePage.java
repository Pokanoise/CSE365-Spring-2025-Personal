package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * AdminHomePage represents the main dashboard for the admin user.
 */
public class AdminHomePage {
    private final DatabaseHelper databaseHelper;
    private final User user;

    public AdminHomePage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
    }

    /**
     * Displays the admin home page.
     * @param primaryStage The primary stage where the scene will be displayed.
     */
    public void show(Stage primaryStage) {
        VBox layout = new VBox(15);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        // Welcome message
        Label adminLabel = new Label("Hello, Admin!");
        adminLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Button to generate an invitation code
        Button generateCodeButton = new Button("Generate Invitation Code");
        generateCodeButton.setOnAction(e -> {
            String code = databaseHelper.generateInvitationCode();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Invite Code");
            alert.setHeaderText("New User Invitation Code");
            alert.setContentText("Generated Code: " + code);
            alert.showAndWait();
        });

        // Button to navigate to the Question Page
        Button questionPageButton = new Button("Go to Question Page");
        questionPageButton.setOnAction(e -> new QuestionPage(databaseHelper).show(primaryStage));

        // Button to Logout
        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> new SetupLoginSelectionPage(databaseHelper).show(primaryStage));

        layout.getChildren().addAll(adminLabel, generateCodeButton, questionPageButton, logoutButton);
        Scene adminScene = new Scene(layout, 800, 400);

        primaryStage.setScene(adminScene);
        primaryStage.setTitle("Admin Page");
        primaryStage.show();
    }
}