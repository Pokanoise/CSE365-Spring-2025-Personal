package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;

public class StaffHomePage extends Application {

    private ListView<String> bannedListView = new ListView<>();
    private ListView<StaffMessage> staffChatView = new ListView<>();
    private ListView<String> feedbackListView = new ListView<>();
    private ListView<String> flaggedContentView = new ListView<>();

    DatabaseHelper databaseHelper = new DatabaseHelper();
    
    //private String currentUser = databaseHelper.getLoggedInUserName();

    public StaffHomePage() throws SQLException {
        databaseHelper = new DatabaseHelper();
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Staff Dashboard");

        // ===== LEFT PANEL: Banned Users =====
        Button unbanButton = new Button("Unban Selected");
        unbanButton.setOnAction(e -> unbanUser());

        VBox bannedBox = new VBox(10, new Label("🔒 Banned Users"), bannedListView, unbanButton);
        bannedBox.setPadding(new Insets(10));
        bannedBox.setPrefWidth(250);

        // ===== RIGHT PANEL: Staff Chat =====
        TextField staffMessageInput = new TextField();
        Button sendStaffMessage = new Button("Send");
        sendStaffMessage.setOnAction(e -> {
            sendMessage(staffMessageInput.getText());
            staffMessageInput.clear();
        });

        HBox staffInputBox = new HBox(5, staffMessageInput, sendStaffMessage);
        VBox staffChatBox = new VBox(10, new Label("📣 Staff Chat"), staffChatView, staffInputBox);
        staffChatBox.setPadding(new Insets(10));
        staffChatBox.setPrefWidth(400);

        // Cell factory for formatting messages
        staffChatView.setCellFactory(lv -> new ListCell<StaffMessage>() {
            @Override
            protected void updateItem(StaffMessage item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Label senderLabel = new Label(item.getSender() + ":");
                    senderLabel.setStyle("-fx-font-weight: bold;");

                    Label messageLabel = new Label(item.getMessage());
                    messageLabel.setWrapText(true);

                    Label timestampLabel = new Label(item.getTimestamp());
                    timestampLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: gray;");

                    Region spacer = new Region();
                    HBox.setHgrow(spacer, Priority.ALWAYS);

                    HBox layout = new HBox(5, senderLabel, messageLabel, spacer, timestampLabel);
                    layout.setPadding(new Insets(5));
                    setGraphic(layout);
                }
            }
        });

        // ===== CENTER: Feedback + Flags =====
        ComboBox<String> feedbackFilter = new ComboBox<>();
        feedbackFilter.getItems().addAll("All", "Bug Report", "UI Suggestion", "Content Issue");
        feedbackFilter.setValue("All");
        feedbackFilter.setOnAction(e -> filterFeedback(feedbackFilter.getValue()));

        VBox feedbackBox = new VBox(10, new Label("📝 Feedback Panel"), feedbackFilter, feedbackListView);
        feedbackBox.setPadding(new Insets(10));

        VBox flaggedBox = new VBox(10, new Label("🚩 Flagged Content"), flaggedContentView);
        flaggedBox.setPadding(new Insets(10));

        VBox centerBox = new VBox(20, feedbackBox, flaggedBox);
        centerBox.setPadding(new Insets(10));
        centerBox.setPrefWidth(400);

        // ===== MAIN LAYOUT =====
        HBox topRow = new HBox(20, bannedBox, staffChatBox, centerBox);
        BorderPane mainLayout = new BorderPane();
        mainLayout.setTop(new Label("Welcome, Staff Member!"));
        mainLayout.setCenter(topRow);

        Scene scene = new Scene(mainLayout, 1100, 700);
        primaryStage.setScene(scene);
        primaryStage.show();

        loadDataIntoUI();
    }

    private void loadDataIntoUI() {
        try {
            databaseHelper.connectToDatabase();

            //currentUser = databaseHelper.getLoggedInUserName();

            // Insert test data
            seedTestDataIfEmpty();

            // Load banned users
            List<String> bannedUsers = databaseHelper.getBannedUsers();
            bannedListView.getItems().addAll(bannedUsers);

            // Load staff messages
            List<StaffMessage> staffMessages = databaseHelper.getStaffMessages();
            staffChatView.getItems().addAll(staffMessages);

            // Load feedback
            List<String> feedbackItems = databaseHelper.getFeedbackByCategory("All");
            feedbackListView.getItems().addAll(feedbackItems);

            // Load flagged content
            List<String> flaggedContent = databaseHelper.getFlaggedContent();
            flaggedContentView.getItems().addAll(flaggedContent);

        } catch (SQLException e) {
            e.printStackTrace();
            showErrorDialog("Database Error", "Failed to load data from the database.");
        }
    }



    private void unbanUser() {
        String selectedUser = bannedListView.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            try {
                databaseHelper.unbanUser(selectedUser);
                bannedListView.getItems().remove(selectedUser);
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorDialog("Database Error", "Unable to unban the user.");
            }
        }
    }

    private void sendMessage(String message) {
        if (!message.isEmpty()) {
            try {
                String name = "Isaiah";
                String timestamp = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                databaseHelper.sendStaffMessage(name, message); // Still store in DB
                staffChatView.getItems().add(new StaffMessage(name, message, timestamp)); // Add formatted message
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorDialog("Database Error", "Failed to send the message.");
            }
        }
    }


    private void filterFeedback(String category) {
        try {
            List<String> filteredFeedback = databaseHelper.getFeedbackByCategory(category);
            feedbackListView.getItems().clear();
            feedbackListView.getItems().addAll(filteredFeedback);
        } catch (SQLException e) {
            e.printStackTrace();
            showErrorDialog("Database Error", "Failed to filter feedback.");
        }
    }

    private void showErrorDialog(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    private void seedTestDataIfEmpty() {
    	
        try {
            // Seed feedback if empty
            if (databaseHelper.getFeedbackByCategory("All").isEmpty()) {
                databaseHelper.submitFeedback("Test Student", "Bug Report", "The submit button crashes the app.");
                databaseHelper.submitFeedback("Test Reviewer", "UI Suggestion", "Can we get dark mode?");
                databaseHelper.submitFeedback("Test Reviewer", "Content Issue", "Question 3 in HW2 is missing requirements.");
                databaseHelper.submitFeedback("Test Student", "Bug Report", "Page doesn’t load after login.");
                databaseHelper.submitFeedback("Test Reviewer", "UI Suggestion", "Make the text editor resizable!");
            }

            // Seed flagged content if empty
            if (databaseHelper.getFlaggedContent().isEmpty()) {
                databaseHelper.flagContent("Test Staff", "Inappropriate answer in QID-203", "Reported multiple times.");
                databaseHelper.flagContent("Test Instructor", "Spam detected in user post ID-487", "Repeated copy-paste answers.");
                databaseHelper.flagContent("Test Staff", "Plagiarized answer in HW1", "Matches external source.");
            }

            // Seed banned users if empty
            if (databaseHelper.getBannedUsers().isEmpty()) {
                // Register users first if they don't exist
                registerUserIfNotExist("Barney The Dino");
                registerUserIfNotExist("Crazy Shrimp Guy32");

                // Now ban them
                databaseHelper.banUser("Barney The Dino");
                databaseHelper.banUser("Crazy Shrimp Guy32");

            }

        } catch (SQLException e) {
            e.printStackTrace();
            showErrorDialog("Test Data Error", "Failed to seed test data.");
        }
    }

    private void registerUserIfNotExist(String userName) throws SQLException {
        if (!databaseHelper.doesUserExist(userName)) {
            User newUser = new User(userName, "password123", "student"); // Adjust password and role as needed
            databaseHelper.register(newUser);
        }
    }




    public static void main(String[] args) {
        launch(args);
    }
}
