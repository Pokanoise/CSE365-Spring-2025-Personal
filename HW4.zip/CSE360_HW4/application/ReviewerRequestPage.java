package application;

import databasePart1.DatabaseHelper;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Modality;
import javafx.scene.layout.HBox;

import java.sql.SQLException;
import java.util.List;

public class ReviewerRequestPage {

    private final DatabaseHelper databaseHelper;
    private final User instructor;

    public ReviewerRequestPage(DatabaseHelper databaseHelper, User instructor) {
        this.databaseHelper = databaseHelper;
        this.instructor = instructor;
    }

    public void show(Stage primaryStage) {
        Label header = new Label("Pending Reviewer Requests");
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ListView<String> studentList = new ListView<>();

        try {
            List<String> students = databaseHelper.getStudentsRequestingReviewer();
            studentList.getItems().addAll(students);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        studentList.setOnMouseClicked(e -> {
            String selectedStudent = studentList.getSelectionModel().getSelectedItem();
            if (selectedStudent != null) {
                showStudentDetailsPopup(selectedStudent);
            }
        });

        Button backButton = new Button("Return");
        backButton.setOnAction(e -> new InstructorHomePage(databaseHelper, instructor).show(primaryStage));

        VBox layout = new VBox(10, header, studentList, backButton);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-alignment: center;");

        primaryStage.setScene(new Scene(layout, 600, 500));
        primaryStage.setTitle("Reviewer Requests");
        primaryStage.show();
    }

    private void showStudentDetailsPopup(String studentUsername) {
        Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        popup.setTitle("Review Request for: " + studentUsername);

        VBox popupLayout = new VBox(10);
        popupLayout.setPadding(new Insets(15));

        Label studentLabel = new Label("Student: " + studentUsername);
        TextArea qaArea = new TextArea();
        qaArea.setEditable(false);

        try {
            List<String> questionsAndAnswers = databaseHelper.getQuestionsAndAnswersByStudent(studentUsername);
            qaArea.setText(String.join("\n\n", questionsAndAnswers));
        } catch (SQLException e) {
            e.printStackTrace();
            qaArea.setText("Error loading student submissions.");
        }

        Button acceptBtn = new Button("Accept Request");
        acceptBtn.setOnAction(e -> {
            try {
                databaseHelper.promoteToReviewer(studentUsername);
                databaseHelper.removeReviewerRequest(studentUsername);
                popup.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        Button denyBtn = new Button("Deny Request");
        denyBtn.setOnAction(e -> {
            try {
                databaseHelper.removeReviewerRequest(studentUsername);
                popup.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        HBox buttonBox = new HBox(10, acceptBtn, denyBtn);
        buttonBox.setStyle("-fx-alignment: center;");

        popupLayout.getChildren().addAll(studentLabel, qaArea, buttonBox);

        Scene popupScene = new Scene(popupLayout, 500, 400);
        popup.setScene(popupScene);
        popup.showAndWait();
    }
}