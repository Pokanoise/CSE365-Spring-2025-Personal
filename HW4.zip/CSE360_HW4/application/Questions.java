package application;

import databasePart1.DatabaseHelper;
import java.sql.SQLException;
import java.util.List;

/**
 * Handles database operations related to Questions.
 */
public class Questions {
    private final DatabaseHelper databaseHelper;

    public Questions(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    /**
     * Adds a question to the database.
     * questionText The question text
     * submittedBy The user who submitted the question
     * SQLException If a database error occurs
     */
    public void addQuestion(String questionText, String submittedBy) throws SQLException {
        if (questionText == null || questionText.trim().isEmpty()) {
            System.out.println("Question cannot be empty.");
            return;
        }
        databaseHelper.saveQuestion(questionText.trim(), "", submittedBy);
    }

    /**
     * Retrieves all questions with their answers.
     * List of formatted questions with answers
     * SQLException If a database error occurs
     */
    public List<String> getAllQuestionsWithAnswers() throws SQLException {
        return databaseHelper.getAllQuestionsWithAnswers();
    }

    /**
     * Retrieves unanswered questions from the database.
     * List of unanswered questions
     * SQLException If a database error occurs
     */
    public List<String> getUnansweredQuestions() throws SQLException {
        return databaseHelper.getUnansweredQuestions();
    }

    /**
     * Deletes a question from the database.
     * questionText The question to delete
     * SQLException If a database error occurs
     */
    public void deleteQuestion(String questionText) throws SQLException {
        if (questionText == null || questionText.trim().isEmpty()) {
            System.out.println("Invalid question.");
            return;
        }
        databaseHelper.deleteQuestion(questionText.trim());
    }
}