package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

public class QuestionPage {
    private final DatabaseHelper databaseHelper;
    private final ListView<String> questionList;
    private final TextField answerField;

    public QuestionPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
        this.questionList = new ListView<>();
        this.answerField = new TextField();
        answerField.setPromptText("Enter your answer");
        answerField.setDisable(true);
    }

    private String getLoggedInUsername() {
        try {
            return databaseHelper.getLoggedInUserName();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void show(Stage primaryStage) {
        TextField questionField = new TextField();
        questionField.setPromptText("Enter your question");

        Button submitQuestionButton = new Button("Submit Question");
        submitQuestionButton.setOnAction(e -> saveQuestion(questionField.getText()));

        Button submitAnswerButton = new Button("Submit Answer");
        submitAnswerButton.setDisable(true);
        submitAnswerButton.setOnAction(e -> updateAnswer(questionList.getSelectionModel().getSelectedItem(), answerField.getText()));

        Button deleteQuestionButton = new Button("Delete Question");
        deleteQuestionButton.setDisable(true);

        Button clearAnswerButton = new Button("Clear Answer");
        clearAnswerButton.setDisable(true);

        Button sendForReviewButton = new Button("Send for Review");
        sendForReviewButton.setDisable(true);
        sendForReviewButton.setOnAction(e -> {
            String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
            if (selectedQuestion != null) {
                try {
                    System.out.println("▶ Original selectedQuestion:");
                    System.out.println("[" + selectedQuestion + "]");

                    String cleanedQuestion = selectedQuestion;

                    if (cleanedQuestion.startsWith("Q: ")) {
                        cleanedQuestion = cleanedQuestion.substring(3);
                    }
                    if (cleanedQuestion.contains("\nA:")) {
                        cleanedQuestion = cleanedQuestion.substring(0, cleanedQuestion.indexOf("\nA:"));
                    }

                    // ✅ Remove author info
                    if (cleanedQuestion.contains(" (by ")) {
                        cleanedQuestion = cleanedQuestion.substring(0, cleanedQuestion.indexOf(" (by "));
                    }

                    cleanedQuestion = cleanedQuestion.trim();

                    System.out.println("✅ Cleaned question for query:");
                    System.out.println("[" + cleanedQuestion + "]");

                    databaseHelper.markQuestionForReview(cleanedQuestion);

                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Question sent for review.");
                    alert.showAndWait();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });


        questionList.setOnMouseClicked(event -> {
            String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
            if (selectedQuestion != null) {
                answerField.setDisable(false);
                submitAnswerButton.setDisable(false);
                deleteQuestionButton.setDisable(false);
                clearAnswerButton.setDisable(false);
                sendForReviewButton.setDisable(false);
            }
        });

        deleteQuestionButton.setOnAction(e -> {
            String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
            if (selectedQuestion != null) {
                deleteQuestion(selectedQuestion);
            }
        });

        clearAnswerButton.setOnAction(e -> {
            String selectedQuestion = questionList.getSelectionModel().getSelectedItem();
            if (selectedQuestion != null) {
                clearAnswer(selectedQuestion);
            }
        });

        Button backButton = new Button("Return");
        backButton.setOnAction(e -> {
            try {
                String username = getLoggedInUsername();
                String role = databaseHelper.getUserRole(username);
                User user = new User(username, "", role);

                switch (role.toLowerCase()) {
                    case "admin":
                        new AdminHomePage(databaseHelper, user).show(primaryStage);
                        break;
                    case "student":
                        new StudentHomePage(databaseHelper, user).show(primaryStage);
                        break;
                    case "reviewer":
                        new ReviewerHomePage(databaseHelper, user).show(primaryStage);
                        break;
                    case "instructor":
                        new InstructorHomePage(databaseHelper, user).show(primaryStage);
                        break;
                    default:
                        System.out.println("Unrecognized role: " + role);
                        break;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(
            questionField, submitQuestionButton, questionList,
            answerField, submitAnswerButton, clearAnswerButton,
            deleteQuestionButton, sendForReviewButton, backButton
        );

        loadQuestions();

        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("Discussion Board");
        primaryStage.show();
    }

    private void saveQuestion(String question) {
        if (question.isEmpty()) return;
        try {
            String username = getLoggedInUsername();
            databaseHelper.saveQuestion(question, "", username);
            loadQuestions();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updateAnswer(String question, String answer) {
        if (answer.isEmpty() || question == null) return;

        if (question.startsWith("Q: ")) question = question.substring(3);
        if (question.contains("\nA: (No answer yet)"))
            question = question.substring(0, question.indexOf("\nA: (No answer yet)"));
        if (question.contains("\nA: ")) // fallback
            question = question.substring(0, question.indexOf("\nA: "));

        try {
            String username = getLoggedInUsername();
            String role = databaseHelper.getUserRole(username);
            if (role == null) return;

            boolean success = databaseHelper.updateAnswerWithRole(question, answer, role, username);
            if (success) System.out.println("Answer updated successfully by " + role);
            else System.out.println("Failed to update answer.");
            loadQuestions();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void deleteQuestion(String question) {
        if (question == null) return;

        if (question.startsWith("Q: ")) question = question.substring(3);
        if (question.contains("\nA:")) question = question.substring(0, question.indexOf("\nA:"));

        try {
            String username = getLoggedInUsername();
            String role = databaseHelper.getUserRole(username);
            if (role == null) return;

            boolean success = databaseHelper.deleteQuestionWithRole(question, role);
            if (success) System.out.println("Successfully deleted question.");
            else System.out.println("Failed to delete question.");
            loadQuestions();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void clearAnswer(String question) {
        if (question == null) return;

        if (question.startsWith("Q: ")) question = question.substring(3);
        if (question.contains("\nA:")) question = question.substring(0, question.indexOf("\nA:"));

        try {
            databaseHelper.clearAnswer(question);
            loadQuestions();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadQuestions() {
        try {
            List<String> questions = databaseHelper.getAllQuestionsWithAnswers();
            questionList.getItems().setAll(questions);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}


