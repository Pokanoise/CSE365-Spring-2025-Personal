package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

public class StudentTrustedReviewerList {

    private final DatabaseHelper databaseHelper;
    private final User student;

    public StudentTrustedReviewerList(DatabaseHelper databaseHelper, User student) {
        this.databaseHelper = databaseHelper;
        this.student = student;
    }

    public void show(Stage primaryStage) {
        Label header = new Label("Trusted Reviewer Reviews");
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ListView<String> listView = new ListView<>();
        loadTrustedReviewerReviews(listView);

        // Input field for weight
        TextField weightField = new TextField();
        weightField.setPromptText("Enter weight for selected reviewer");

        // Button to update weight
        Button updateWeightButton = new Button("Update Weight");
        updateWeightButton.setOnAction(e -> {
            String selectedReview = listView.getSelectionModel().getSelectedItem();
            if (selectedReview != null && selectedReview.contains("Reviewer: ")) {
                String reviewer = extractReviewerUsername(selectedReview);
                try {
                    int weight = Integer.parseInt(weightField.getText());
                    databaseHelper.updateReviewerWeight(student.getUserName(), reviewer, weight);
                    showAlert("Updated weight for " + reviewer + " to " + weight);
                    loadTrustedReviewerReviews(listView); // Refresh with new order
                } catch (NumberFormatException nfe) {
                    showAlert("Please enter a valid number for weight.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    showAlert("Error updating weight.");
                }
            } else {
                showAlert("Please select a review first.");
            }
        });

        // Return button
        Button returnBtn = new Button("Return");
        returnBtn.setOnAction(e -> new StudentHomePage(databaseHelper, student).show(primaryStage));

        VBox layout = new VBox(10, header, listView, weightField, updateWeightButton, returnBtn);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        primaryStage.setScene(new Scene(layout, 800, 550));
        primaryStage.setTitle("Trusted Reviewer Reviews");
        primaryStage.show();
    }

    private void loadTrustedReviewerReviews(ListView<String> listView) {
        try {
            List<String> reviews = databaseHelper.getReviewsFromTrustedReviewers(student.getUserName());
            listView.getItems().setAll(reviews);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Failed to load trusted reviews.");
        }
    }

    private String extractReviewerUsername(String reviewText) {
        int reviewerIndex = reviewText.indexOf("Reviewer: ");
        if (reviewerIndex != -1) {
            String after = reviewText.substring(reviewerIndex + "Reviewer: ".length());
            return after.split(" \\|")[0].trim(); // stop before next delimiter
        }
        return null;
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}