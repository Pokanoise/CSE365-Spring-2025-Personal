package application;

import databasePart1.DatabaseHelper;
import java.sql.SQLException;

/**
 * Handles database operations related to Answers.
 */
public class Answers {
    private final DatabaseHelper databaseHelper;

    public Answers(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    /**
     * Saves an answer to a question in the database.
     * questionText The question being answered
     * answerText The answer text
     *  answeredBy The user providing the answer
     * SQLException If a database error occurs
     */
    public void saveAnswer(String questionText, String answerText, String answeredBy) throws SQLException {
        if (answerText == null || answerText.trim().isEmpty() || questionText == null) {
            System.out.println("No question selected or empty answer!");
            return;
        }
        databaseHelper.updateAnswer(questionText.trim(), answerText.trim());
    }

    /**
     * Clears the answer to a question.
     * questionText The question whose answer is being cleared
     * SQLException If a database error occurs
     */
    public void clearAnswer(String questionText) throws SQLException {
        if (questionText == null || questionText.trim().isEmpty()) {
            System.out.println("Invalid question.");
            return;
        }
        databaseHelper.clearAnswer(questionText.trim());
    }
}