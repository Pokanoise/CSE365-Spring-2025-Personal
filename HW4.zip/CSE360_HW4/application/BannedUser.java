package application;

public class BannedUser {

	private String userName;
    private boolean isBanned;

    public BannedUser(String userName, boolean isBanned) {
        this.userName = userName;
        this.isBanned = isBanned;
    }

    public String getUserName() {
        return userName;
    }

    public boolean isBanned() {
        return isBanned;
    }

    public void setBanned(boolean banned) {
        this.isBanned = banned;
    }
}
