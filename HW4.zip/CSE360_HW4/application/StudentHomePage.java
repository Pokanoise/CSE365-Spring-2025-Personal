package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.SQLException;

/**
 * StudentHomePage is the landing page for users with the 'student' role.
 * It allows navigation to private messages, the discussion board, or logging out.
 */
public class StudentHomePage {

    private final DatabaseHelper databaseHelper;
    private final User user;

    public StudentHomePage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
    }

    /**
     * Displays the student home page.
     * @param primaryStage The main application window.
     */
    public void show(Stage primaryStage) {
        Label welcomeLabel = new Label("Welcome, " + user.getUserName() + " (Student)");
        welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Button privateMessagesButton = new Button("View Private Messages");
        privateMessagesButton.setOnAction(e -> {
            new PrivateMessaging(databaseHelper, user).show(primaryStage);
        });

        Button discussionBoardButton = new Button("Go to Discussion Board");
        discussionBoardButton.setOnAction(e -> {
            new QuestionPage(databaseHelper).show(primaryStage);
        });
        
        Button reviewListButton = new Button("List of Reviews");
        reviewListButton.setOnAction(e -> {
            new StudentReviewList(databaseHelper, user).show(primaryStage);
        });
        
        Button trustedReviewerListButton = new Button("Trusted Reviewer List");
        trustedReviewerListButton.setOnAction(e -> {
            new StudentTrustedReviewerList(databaseHelper, user).show(primaryStage);
        });
        
        Button requestReviewerButton = new Button("Request to Become a Reviewer");
        requestReviewerButton.setOnAction(e -> {
            try {
                databaseHelper.sendReviewerRequest(user.getUserName());
                System.out.println("✅ Reviewer request successfully sent for: " + user.getUserName());
            } catch (SQLException ex) {
                System.out.println("❌ Failed to send reviewer request for: " + user.getUserName());
                ex.printStackTrace();
            }
        });

        Button logoutButton = new Button("Log Out");
        logoutButton.setOnAction(e -> {
            new SetupLoginSelectionPage(databaseHelper).show(primaryStage);
        });

        VBox layout = new VBox(15);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(welcomeLabel, privateMessagesButton, discussionBoardButton, reviewListButton, trustedReviewerListButton, requestReviewerButton, logoutButton);

        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("Student Home");
        primaryStage.show();
    }
}