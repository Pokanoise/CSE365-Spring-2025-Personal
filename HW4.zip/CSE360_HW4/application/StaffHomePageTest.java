package application;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import databasePart1.DatabaseHelper;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

public class StaffHomePageTest {

    private DatabaseHelper mockDatabaseHelper;
    private StaffHomePage staffHomePage;

    @Before
    public void setUp() throws SQLException {
        // Mock DatabaseHelper to avoid actual DB interaction
        mockDatabaseHelper = Mockito.mock(DatabaseHelper.class);
        staffHomePage = new StaffHomePage();
        staffHomePage.databaseHelper = mockDatabaseHelper; // Set the mock database helper to the staffHomePage instance
    }

    @Test
    public void testLoadDataIntoUI() throws SQLException {
        // Arrange
        List<String> bannedUsers = Arrays.asList("TrollUser123", "SpamBot42");
        List<StaffMessage> staffMessages = Arrays.asList(new StaffMessage("Isaiah", "Test Message", "2025-04-11 12:00"));
        List<String> feedbackItems = Arrays.asList("Bug A", "UI B", "Content C");
        List<String> flaggedContent = Arrays.asList("Spam in ID 123", "Plagiarism in HW1");

        // Mock the behavior of the database helper
        Mockito.when(mockDatabaseHelper.getBannedUsers()).thenReturn(bannedUsers);
        Mockito.when(mockDatabaseHelper.getStaffMessages()).thenReturn(staffMessages);
        Mockito.when(mockDatabaseHelper.getFeedbackByCategory("All")).thenReturn(feedbackItems);
        Mockito.when(mockDatabaseHelper.getFlaggedContent()).thenReturn(flaggedContent);

        // Act
        staffHomePage.loadDataIntoUI();

        // Assert
        assertEquals(2, staffHomePage.bannedListView.getItems().size());
        assertTrue(staffHomePage.bannedListView.getItems().contains("TrollUser123"));
        assertEquals(1, staffHomePage.staffChatView.getItems().size());
        assertEquals("Test Message", staffHomePage.staffChatView.getItems().get(0).getMessage());
        assertEquals(3, staffHomePage.feedbackListView.getItems().size());
        assertEquals("Bug A", staffHomePage.feedbackListView.getItems().get(0));
        assertEquals(2, staffHomePage.flaggedContentView.getItems().size());
    }

    @Test
    public void testSendMessage() throws SQLException {
        // Arrange
        String message = "Test message for staff chat";

        // Act
        staffHomePage.sendMessage(message);

        // Assert that the method sends the message and adds it to the staff chat
        Mockito.verify(mockDatabaseHelper).sendStaffMessage("Isaiah", message);
        assertEquals(1, staffHomePage.staffChatView.getItems().size());
        assertEquals(message, staffHomePage.staffChatView.getItems().get(0).getMessage());
    }

    @Test
    public void testUnbanUser() throws SQLException {
        // Arrange
        String userToUnban = "TrollUser123";
        Mockito.when(mockDatabaseHelper.getBannedUsers()).thenReturn(Arrays.asList(userToUnban));

        // Act
        staffHomePage.unbanUser();

        // Assert
        Mockito.verify(mockDatabaseHelper).unbanUser(userToUnban);
        assertFalse(staffHomePage.bannedListView.getItems().contains(userToUnban));
    }

    @Test
    public void testFilterFeedback() throws SQLException {
        // Arrange
        String category = "Bug Report";
        List<String> feedbackItems = Arrays.asList("Bug A", "Bug B");

        Mockito.when(mockDatabaseHelper.getFeedbackByCategory(category)).thenReturn(feedbackItems);

        // Act
        staffHomePage.filterFeedback(category);

        // Assert
        assertEquals(2, staffHomePage.feedbackListView.getItems().size());
        assertTrue(staffHomePage.feedbackListView.getItems().contains("Bug A"));
        assertTrue(staffHomePage.feedbackListView.getItems().contains("Bug B"));
    }

    @Test
    public void testRegisterUserIfNotExist() throws SQLException {
        // Arrange
        String newUserName = "NewUser";
        Mockito.when(mockDatabaseHelper.doesUserExist(newUserName)).thenReturn(false);

        // Act
        staffHomePage.registerUserIfNotExist(newUserName);

        // Assert
        Mockito.verify(mockDatabaseHelper).register(Mockito.any(User.class));
    }
}
