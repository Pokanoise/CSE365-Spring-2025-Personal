package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.SQLException;

import databasePart1.*;

/**
 * SetupAccountPage handles the account creation for new users using invitation codes.
 * After successful registration, users are redirected to the student home page.
 */
public class SetupAccountPage {

    private final DatabaseHelper databaseHelper;

    public SetupAccountPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
        // Load welcome image
        Image newUserImage = new Image(getClass().getResourceAsStream("/image/New_User_Welcome_Page.png"));
        ImageView backgroundView = new ImageView(newUserImage);

        StackPane stackPane = new StackPane();

        TextField userNameField = new TextField();
        userNameField.setPromptText("Enter Username");
        userNameField.setMaxWidth(250);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        passwordField.setMaxWidth(250);

        TextField inviteCodeField = new TextField();
        inviteCodeField.setPromptText("Enter Invitation Code");
        inviteCodeField.setMaxWidth(250);

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        Button setupButton = new Button("Setup Account");

        setupButton.setOnAction(a -> {
            String userName = userNameField.getText();
            String password = passwordField.getText();
            String code = inviteCodeField.getText();

            String usernameFeedback = UsernameEvaluator.evaluateUsername(userName);
            if (!usernameFeedback.startsWith("Valid Username")) {
                showAlert("Username Error", usernameFeedback);
                return;
            }

            String passwordFeedback = PasswordEvaluator.evaluatePassword(password);
            if (!passwordFeedback.startsWith("Valid Password")) {
                showAlert("Password Error", passwordFeedback);
                return;
            }

            try {
                if (!databaseHelper.doesUserExist(userName)) {
                    if (databaseHelper.validateInvitationCode(code)) {
                        // Default all new users to "student"
                        User user = new User(userName, password, "student");
                        databaseHelper.register(user);
                        databaseHelper.setLoggedIn(userName);

                        new StudentHomePage(databaseHelper, user).show(primaryStage);
                    } else {
                        errorLabel.setText("Invalid or expired invitation code.");
                    }
                } else {
                    errorLabel.setText("Username already exists. Please choose another.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                errorLabel.setText("Database error occurred.");
            }
        });

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(userNameField, passwordField, inviteCodeField, setupButton, errorLabel);

        stackPane.getChildren().addAll(backgroundView, layout);

        primaryStage.setScene(new Scene(stackPane, 800, 400));
        primaryStage.setTitle("Create New Account");
        primaryStage.show();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

