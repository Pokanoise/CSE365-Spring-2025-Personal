package application;

import databasePart1.DatabaseHelper;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

/**
 * ReviewPage allows a reviewer to create, update, view, and delete reviews.
 */
public class ReviewPage {

    private final DatabaseHelper databaseHelper;
    private final User reviewer;

    public ReviewPage(DatabaseHelper databaseHelper, User reviewer) {
        this.databaseHelper = databaseHelper;
        this.reviewer = reviewer;
    }

    public void show(Stage primaryStage) {
        Label header = new Label("Review Center - Welcome " + reviewer.getUserName());
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Section for pending reviews
        Label pendingLabel = new Label("Questions Needing Review:");
        pendingReviewList = new ListView<>();
        Button loadReviewTargetsBtn = new Button("Load Review Targets");

        loadReviewTargetsBtn.setOnAction(e -> {
            try {
                List<String> pending = databaseHelper.getQuestionsMarkedForReview();
                pendingReviewList.getItems().setAll(pending);
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("Failed to load pending review questions.");
            }
        });

        pendingReviewList.setOnMouseClicked(e -> {
            String selected = pendingReviewList.getSelectionModel().getSelectedItem();
            if (selected != null) {
                String[] parts = selected.split("\n");
                if (parts.length >= 3) {
                    String qText = parts[0].replace("Q: ", "").trim();
                    String aText = parts[2].replace("A: ", "").trim();

                    questionField.setText(qText);
                    answerField.setText(aText);
                }
            }
        });

        // Review submission fields
        questionField = new TextField();
        questionField.setPromptText("Question being reviewed");

        answerField = new TextField();
        answerField.setPromptText("Answer being reviewed");

        TextArea reviewTextArea = new TextArea();
        reviewTextArea.setPromptText("Write your review here...");
        reviewTextArea.setWrapText(true);

        TextField reviewIdField = new TextField();
        reviewIdField.setPromptText("Review ID (for update/delete)");

        Button submitReviewBtn = new Button("Submit Review");
        submitReviewBtn.setOnAction(e -> {
            try {
                databaseHelper.saveReview(
                    reviewer.getUserName(),
                    questionField.getText(),
                    answerField.getText(),
                    reviewTextArea.getText()
                );
                showAlert("Review submitted!");
                refreshReviewList();
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("Error submitting review.");
            }
        });

        Button updateReviewBtn = new Button("Update Review");
        updateReviewBtn.setOnAction(e -> {
            try {
                int reviewId = Integer.parseInt(reviewIdField.getText());
                boolean updated = databaseHelper.updateReview(reviewId, reviewTextArea.getText());
                showAlert(updated ? "Review updated!" : "Update failed.");
                refreshReviewList();
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error updating review.");
            }
        });

        Button deleteReviewBtn = new Button("Delete Review");
        deleteReviewBtn.setOnAction(e -> {
            try {
                int reviewId = Integer.parseInt(reviewIdField.getText());
                boolean deleted = databaseHelper.deleteReview(reviewId);
                showAlert(deleted ? "Review deleted!" : "Delete failed.");
                refreshReviewList();
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error deleting review.");
            }
        });

        reviewList = new ListView<>();

        Button refreshBtn = new Button("Refresh My Reviews");
        refreshBtn.setOnAction(e -> refreshReviewList());

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> new ReviewerHomePage(databaseHelper, reviewer).show(primaryStage));

        VBox layout = new VBox(10,
                header,
                pendingLabel,
                loadReviewTargetsBtn,
                pendingReviewList,
                questionField,
                answerField,
                reviewTextArea,
                reviewIdField,
                submitReviewBtn,
                updateReviewBtn,
                deleteReviewBtn,
                refreshBtn,
                reviewList,
                backBtn
        );

        layout.setPadding(new Insets(20));
        primaryStage.setScene(new Scene(layout, 800, 650));
        primaryStage.setTitle("Review Page");
        primaryStage.show();

        refreshReviewList();
    }

    private ListView<String> reviewList;
    private ListView<String> pendingReviewList;
    private TextField questionField;
    private TextField answerField;

    private void refreshReviewList() {
        try {
            List<String> reviews = databaseHelper.getReviewsByReviewer(reviewer.getUserName());
            reviewList.getItems().setAll(reviews);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Failed to load reviews.");
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
