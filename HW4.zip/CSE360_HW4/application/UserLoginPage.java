package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;

import databasePart1.*;

/**
 * The UserLoginPage class provides a login interface for users to access their accounts.
 * It validates the user's credentials and navigates to the appropriate page upon successful login.
 */
public class UserLoginPage {

    private final DatabaseHelper databaseHelper;

    public UserLoginPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
        // Instructional text
        TextArea requirementsBox = new TextArea();
        requirementsBox.setText("Welcome!\nIf you are an Admin, Instructor, Reviewer, or Student, please login here.");
        requirementsBox.setWrapText(true);
        requirementsBox.setEditable(false);
        requirementsBox.setStyle("-fx-font-size: 12px; -fx-padding: 10;");
        requirementsBox.setMaxWidth(300);
        requirementsBox.setMinHeight(100);

        // Input fields
        TextField userNameField = new TextField();
        userNameField.setPromptText("Enter Username");
        userNameField.setMaxWidth(250);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        passwordField.setMaxWidth(250);

        // Error message label
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        // Login button
        Button loginButton = new Button("Login");

        loginButton.setOnAction(a -> {
            String userName = userNameField.getText();
            String password = passwordField.getText();

            try {
                User user = new User(userName, password, "");

                // Retrieve role from DB
                String role = databaseHelper.getUserRole(userName);

                if (role != null) {
                    user.setRole(role);
                    if (databaseHelper.login(user)) {
                        databaseHelper.setLoggedIn(userName); // mark user as logged in

                        switch (role.toLowerCase()) {
                            case "admin":
                                new AdminHomePage(databaseHelper, user).show(primaryStage);
                                break;
                            case "student":
                                new StudentHomePage(databaseHelper, user).show(primaryStage);
                                break;
                            case "reviewer":
                                new ReviewerHomePage(databaseHelper, user).show(primaryStage);
                                break;
                            case "instructor":
                                new InstructorHomePage(databaseHelper, user).show(primaryStage);
                                break;
                            default:
                                errorLabel.setText("Unknown role: " + role);
                                break;
                        }

                    } else {
                        errorLabel.setText("Incorrect username or password.");
                    }
                } else {
                    errorLabel.setText("User account does not exist.");
                }

            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
                e.printStackTrace();
                errorLabel.setText("Database error occurred.");
            }
        });

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(requirementsBox, userNameField, passwordField, loginButton, errorLabel);

        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("User Login");
        primaryStage.show();
    }
}
