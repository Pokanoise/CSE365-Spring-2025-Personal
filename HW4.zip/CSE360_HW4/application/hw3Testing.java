package application;

import databasePart1.DatabaseHelper;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * hw3Testing.java
 * Automated testing of question addition and answer modification functionality with role-based access control.
 * Tests include:
 * 1. Student adding a question.
 * 2. Admin adding a question.
 * 3. Reviewer adding a question.
 * 4. Reviewer deleting an answer.
 * 5. Reviewer answering a question.
 */
public class hw3Testing {

    private static final Logger logger = Logger.getLogger(hw3Testing.class.getName());
    private DatabaseHelper databaseHelper = new DatabaseHelper();

    /**
     * Default constructor for hw3Testing.
     * Initializes the database helper.
     */
    public hw3Testing() {
        databaseHelper = new DatabaseHelper();
    }

    /**
     * Main method to execute the testing functions.
     * Calls each of the test methods to verify functionality.
     * Tests include adding questions and modifying answers by different roles.
     * @param args Command-line arguments (not used)
     */
    public static void main(String[] args) {
        hw3Testing tester = new hw3Testing();
        tester.testStudentCanAddQuestion();
        tester.testAdminCanAddQuestion();
        tester.testReviewerCanAddQuestion();
        tester.testReviewerCanDeleteAnswer();
        tester.testReviewerCanAnswerQuestion();
    }

    /**
     * Tests whether a student can add a question to the database.
     * Verifies that the question is added successfully with the student role.
     */
    void testStudentCanAddQuestion() {
        String question = "What is the best way to study C++?";
        try {
            databaseHelper.connectToDatabase();
            boolean result = databaseHelper.saveQuestionWithRole(question, "", "student");
            if (result) {
                logger.info("Test Passed: Student successfully added a question.");
            } else {
                logger.warning("Test Failed: Student could not add a question.");
            }
        } catch (SQLException e) {
            logger.severe("SQLException occurred: " + e.getMessage());
        } finally {
            databaseHelper.closeConnection();
        }
    }

    /**
     * Tests whether an admin can add a question to the database.
     * Verifies that the question is added successfully with the admin role.
     */
    void testAdminCanAddQuestion() {
        String question = "How do you guy's as students feel about the discussion board?";
        try {
            databaseHelper.connectToDatabase();
            boolean result = databaseHelper.saveQuestionWithRole(question, "", "admin");
            if (result) {
                logger.info("Test Passed: Admin successfully added a question.");
            } else {
                logger.warning("Test Failed: Admin could not add a question.");
            }
        } catch (SQLException e) {
            logger.severe("SQLException occurred: " + e.getMessage());
        } finally {
            databaseHelper.closeConnection();
        }
    }

    /**
     * Tests whether a reviewer can add a question to the database.
     * Verifies that the question is added successfully with the reviewer role.
     */
    void testReviewerCanAddQuestion() {
        String question = "Do people like the answers I have been changing on the discussion board?";
        try {
            databaseHelper.connectToDatabase();
            boolean result = databaseHelper.saveQuestionWithRole(question, "", "reviewer");
            if (result) {
                logger.info("Test Passed: Reviewer successfully added a question.");
            } else {
                logger.warning("Test Failed: Reviewer could not add a question.");
            }
        } catch (SQLException e) {
            logger.severe("SQLException occurred: " + e.getMessage());
        } finally {
            databaseHelper.closeConnection();
        }
    }

    /**
     * Tests whether a reviewer can delete an answer.
     * Verifies that the answer is successfully deleted using the reviewer role.
     */
    void testReviewerCanDeleteAnswer() {
        String question = "When is TP3 due?";
        try {
            databaseHelper.connectToDatabase();
            boolean result = databaseHelper.deleteAnswerWithRole(question, "reviewer");
            if (result) {
                logger.info("Test Passed: Reviewer successfully deleted an answer.");
            } else {
                logger.warning("Test Failed: Reviewer could not delete the answer.");
            }
        } catch (SQLException e) {
            logger.severe("SQLException occurred: " + e.getMessage());
        } finally {
            databaseHelper.closeConnection();
        }
    }

    /**
     * Tests whether a reviewer can answer a question.
     * Verifies that the answer is successfully added using the reviewer role.
     */
    void testReviewerCanAnswerQuestion() {
        String question = "When is TP4 due?";
        String answer = "By the end of the month.";
        try {
            databaseHelper.connectToDatabase();
            boolean result = databaseHelper.updateAnswerWithRole(question, answer, "reviewer", "reviewerName");
            if (result) {
                logger.info("Test Passed: Reviewer successfully answered the question.");
            } else {
                logger.warning("Test Failed: Reviewer could not answer the question.");
            }
        } catch (SQLException e) {
            logger.severe("SQLException occurred: " + e.getMessage());
        } finally {
            databaseHelper.closeConnection();
        }
    }
}