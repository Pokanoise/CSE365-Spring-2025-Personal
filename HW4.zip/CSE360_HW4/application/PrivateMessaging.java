package application;

import databasePart1.DatabaseHelper;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

/**
 * Provides a private messaging interface for users to send and receive messages.
 */
public class PrivateMessaging {
    private final DatabaseHelper databaseHelper;
    private final User currentUser;

    public PrivateMessaging(DatabaseHelper databaseHelper, User currentUser) {
        this.databaseHelper = databaseHelper;
        this.currentUser = currentUser;
    }

    public void show(Stage primaryStage) {
        Label header = new Label("Private Messaging");
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ComboBox<String> recipientDropdown = new ComboBox<>();
        try {
            List<String> allUsers = databaseHelper.getAllUsernamesExcept(currentUser.getUserName());
            recipientDropdown.setItems(FXCollections.observableArrayList(allUsers));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TextArea messageBox = new TextArea();
        messageBox.setPromptText("Enter your message here...");
        messageBox.setWrapText(true);

        Button sendButton = new Button("Send Message");
        sendButton.setOnAction(e -> {
            String recipient = recipientDropdown.getValue();
            String message = messageBox.getText();
            if (recipient != null && !message.trim().isEmpty()) {
                try {
                    databaseHelper.sendPrivateMessage(currentUser.getUserName(), recipient, message.trim());
                    messageBox.clear();
                    showMessages(messagesArea);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        messagesArea.setEditable(false);
        showMessages(messagesArea);

        // 🔁 Role-based back button navigation
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            String role = currentUser.getRole().toLowerCase();
            switch (role) {
                case "admin":
                    new AdminHomePage(databaseHelper, currentUser).show(primaryStage);
                    break;
                case "student":
                    new StudentHomePage(databaseHelper, currentUser).show(primaryStage);
                    break;
                case "reviewer":
                    new ReviewerHomePage(databaseHelper, currentUser).show(primaryStage);
                    break;
                case "instructor":
                    new InstructorHomePage(databaseHelper, currentUser).show(primaryStage);
                    break;
                default:
                    System.out.println("Unknown role: " + role);
            }
        });

        GridPane inputPane = new GridPane();
        inputPane.setPadding(new Insets(10));
        inputPane.setVgap(10);
        inputPane.setHgap(10);
        inputPane.add(new Label("To:"), 0, 0);
        inputPane.add(recipientDropdown, 1, 0);
        inputPane.add(messageBox, 0, 1, 2, 1);
        inputPane.add(sendButton, 0, 2);

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(header, inputPane, new Label("Messages"), messagesArea, backButton);

        primaryStage.setScene(new Scene(layout, 800, 500));
        primaryStage.setTitle("Private Messaging");
        primaryStage.show();
    }

    private TextArea messagesArea = new TextArea();

    private void showMessages(TextArea area) {
        try {
            List<String> messages = databaseHelper.getMessagesForUser(currentUser.getUserName());
            StringBuilder content = new StringBuilder();
            for (String message : messages) {
                content.append(message).append("\n\n");
            }
            area.setText(content.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}