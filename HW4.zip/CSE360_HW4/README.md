This code now has our Reviewer and Student Features and the private messaging system. We accomplished this task by adding a ReviewerHomePage.java, ReviewerRequestPage.java, Review.java, StudentReviewList.java, StudentTrustedReviewList.java, and JUnitSendReviewerRequestTest.java. This now shows our discussion board page which can be accessed through different roles such as students, reviewers, and admin. Reviwers could answer questions asked by students and they could review potential answers and give their feedback on it. Students can also give weightage to different reviewers and they can list them as their Trusted Reviwers.

The Javadoc is listed below:

https://drive.google.com/drive/folders/13cM985k30dK-8ZVxwUsas6Ot7tY4dUJt?usp=drive_link

We have also pasted the screencasts below.

Screencast for the JUnit Testing and the immplementation plan is linked below.

[https://asu.zoom.us/rec/share/B7YKAOS5tgv57o48YcSN-SjmA8e4VdHLjgpmGeYatV2shqYgaCjLYgMMU_ITKDdn.wkD6huKfQ00BEFLO](url)
Password:tXf&M0He

Screencast for the Architecture Plan and the design documents is linked below.

[https://asu.zoom.us/rec/share/V3ianbbsS1j3AuZ3IiXXVZYR0T8aYImGe7aerlt0xsoYWlLetEDwSpGVrFYAv9Fg.wG29DANQo1oNcs2d](url)
Password: Gx9PqJ.^

Screencast for the Standup Meetings in linked below.

Week 10: [03-19-2025 Standup Meeting Week 1](url)

Week 11: [03-26-2025 Standup Meeting Week 2](url)

Week 12: [04-02-2025 Standup Meeting Week 3](URL)


*** Updated Links to Architecture and Design Documents ***

Architecture ~ 

  System Diagram #1: https://poka.s-ul.eu/RUNiogow

Design ~

  Class Diagram (Database Simple):  https://poka.s-ul.eu/XEnGOuWf
  
  Class Diagram (Application Simple): https://poka.s-ul.eu/ROOLTu1A
